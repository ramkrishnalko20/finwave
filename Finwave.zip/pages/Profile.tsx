
import React, { useState } from 'react';
import { ChevronLeft, Mail, Phone, MapPin, Calendar, Briefcase, User, Info, CheckCircle, Shield, ArrowRight, Save, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { usePortfolio } from '../PortfolioContext';

const Profile: React.FC = () => {
  const { user, updateUser } = usePortfolio();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email,
    phone: user.phone,
    dob: user.dob,
    nominee: user.nominee
  });

  const handleSave = () => {
    updateUser(formData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData({
      name: user.name,
      email: user.email,
      phone: user.phone,
      dob: user.dob,
      nominee: user.nominee
    });
    setIsEditing(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <div className="p-6 pb-24">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
            <Link to="/account" className="p-2 bg-slate-100 rounded-full text-slate-600 active:scale-90 transition-transform">
            <ChevronLeft size={20} />
            </Link>
            <h1 className="text-xl font-black text-slate-800 tracking-tight">Personal Profile</h1>
        </div>
        {isEditing && (
            <div className="flex gap-2">
                <button onClick={handleCancel} className="p-2 bg-red-50 text-red-500 rounded-full"><X size={18} /></button>
                <button onClick={handleSave} className="p-2 bg-emerald-50 text-emerald-500 rounded-full"><Save size={18} /></button>
            </div>
        )}
      </div>

      <div className="flex flex-col items-center mb-10">
        <div className="relative mb-4 group">
          <img 
            src={user.avatar} 
            alt="Profile" 
            className="w-24 h-24 rounded-[32px] border-4 border-white shadow-2xl object-cover"
          />
          <div className={`absolute -bottom-1 -right-1 p-1.5 rounded-xl border-4 border-white shadow-lg ${user.kycStatus === 'Verified' ? 'bg-emerald-500' : 'bg-amber-500'}`}>
            <Shield size={14} className="text-white" />
          </div>
        </div>
        {isEditing ? (
            <input 
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="text-2xl font-black text-slate-800 text-center bg-slate-50 border-b-2 border-blue-500 outline-none w-full max-w-xs"
            />
        ) : (
            <h2 className="text-2xl font-black text-slate-800 tracking-tight">{user.name}</h2>
        )}
        <p className="text-slate-400 text-xs font-black uppercase tracking-widest mt-1">Portfolio Owner</p>
      </div>

      <div className="space-y-8">
        <section>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Contact Information</h3>
          </div>
          <div className="space-y-6">
            <div className="flex items-center gap-4 bg-white p-4 rounded-[24px] border border-slate-50 shadow-sm">
                <div className="bg-blue-50 p-3 rounded-2xl">
                    <Mail size={20} className="text-blue-500" />
                </div>
                <div className="flex-1">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Email Address</p>
                    {isEditing ? (
                        <input name="email" value={formData.email} onChange={handleChange} className="font-bold text-slate-800 w-full outline-none bg-transparent" />
                    ) : (
                        <p className="font-bold text-slate-800 text-sm">{user.email}</p>
                    )}
                </div>
            </div>
            <div className="flex items-center gap-4 bg-white p-4 rounded-[24px] border border-slate-50 shadow-sm">
                <div className="bg-emerald-50 p-3 rounded-2xl">
                    <Phone size={20} className="text-emerald-500" />
                </div>
                <div className="flex-1">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Phone Number</p>
                    {isEditing ? (
                        <input name="phone" value={formData.phone} onChange={handleChange} className="font-bold text-slate-800 w-full outline-none bg-transparent" />
                    ) : (
                        <p className="font-bold text-slate-800 text-sm">{user.phone}</p>
                    )}
                </div>
            </div>
          </div>
        </section>

        <section>
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Account Metadata</h3>
          <div className="bg-white rounded-[32px] border border-slate-100 p-6 space-y-6 shadow-sm">
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Calendar size={18} className="text-purple-500" />
                    <span className="text-xs font-bold text-slate-600 uppercase tracking-tight">Date of Birth</span>
                </div>
                {isEditing ? (
                    <input type="date" name="dob" value={formData.dob} onChange={handleChange} className="font-bold text-slate-800 text-xs outline-none bg-slate-50 p-1 rounded" />
                ) : (
                    <span className="text-sm font-bold text-slate-800">{user.dob}</span>
                )}
            </div>
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <User size={18} className="text-amber-500" />
                    <span className="text-xs font-bold text-slate-600 uppercase tracking-tight">Nominee</span>
                </div>
                {isEditing ? (
                    <input name="nominee" value={formData.nominee} onChange={handleChange} className="font-bold text-slate-800 text-xs outline-none bg-slate-50 p-1 rounded text-right" />
                ) : (
                    <span className="text-sm font-bold text-slate-800">{user.nominee}</span>
                )}
            </div>
            <div className="flex justify-between items-center pt-6 border-t border-slate-50">
                <div className="flex items-center gap-3">
                    <Shield size={18} className="text-blue-600" />
                    <span className="text-xs font-bold text-slate-600 uppercase tracking-tight">KYC Status</span>
                </div>
                <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${user.kycStatus === 'Verified' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                        {user.kycStatus}
                    </span>
                    <button 
                        onClick={() => navigate('/kyc')}
                        className="p-1.5 bg-slate-50 rounded-lg text-slate-400 hover:text-blue-600"
                    >
                        <ArrowRight size={14} />
                    </button>
                </div>
            </div>
          </div>
        </section>

        {!isEditing && (
            <button 
                onClick={() => setIsEditing(true)}
                className="w-full py-5 bg-[#0059B2] text-white font-black rounded-[24px] shadow-xl shadow-blue-100 uppercase text-[10px] tracking-widest hover:brightness-110 active:scale-98 transition-all"
            >
                Edit Information
            </button>
        )}
      </div>
    </div>
  );
};

export default Profile;
