import React, { useState, useEffect, useRef } from 'react';
import { Menu, Bell, TrendingUp, ChevronRight, ArrowUpRight, ShoppingCart, Loader2, Plus, Minus } from 'lucide-react';
import { PieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { MOCK_USER, MOCK_NOTIFICATIONS } from '../constants';
import { Link, useNavigate } from 'react-router-dom';
import { useUI } from '../App';
import { Folio } from '../types';
import { usePortfolio } from '../PortfolioContext';

const Home: React.FC = () => {
  const { folios, quickTransaction, formatCurrency } = usePortfolio();
  const { setMenuOpen, isNotifOpen, setNotifOpen } = useUI();
  const [liveFolios, setLiveFolios] = useState<Folio[]>([]);
  const [portfolioTotal, setPortfolioTotal] = useState(0);
  const [portfolioGain, setPortfolioGain] = useState(0);
  const [portfolioInvested, setPortfolioInvested] = useState(0);
  const [realTimeChartData, setRealTimeChartData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // State for dynamic asset allocation
  const [assetAllocation, setAssetAllocation] = useState<{ name: string; value: number; color: string }[]>([
    { name: 'Empty', value: 100, color: '#f1f5f9' }
  ]);
  const [maxAsset, setMaxAsset] = useState<{ name: string; value: number }>({ name: 'No Assets', value: 0 });

  const navigate = useNavigate();
  const notifRef = useRef<HTMLDivElement>(null);

  const getAssetColor = (type: string) => {
    switch(type) {
        case 'Equity': return '#3b82f6'; // blue-500
        case 'Debt': return '#10b981';   // emerald-500
        case 'Hybrid': return '#8b5cf6'; // violet-500
        case 'Gold': return '#f59e0b';   // amber-500
        default: return '#94a3b8';       // slate-400
    }
  };

  useEffect(() => {
    const fetchRealTimeData = async () => {
      if (folios.length === 0) {
        setLiveFolios([]);
        setPortfolioTotal(0);
        setPortfolioGain(0);
        setPortfolioInvested(0);
        setAssetAllocation([{ name: 'Empty', value: 100, color: '#f1f5f9' }]);
        setMaxAsset({ name: 'No Assets', value: 0 });
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        const allocationMap: Record<string, number> = { 'Equity': 0, 'Debt': 0, 'Hybrid': 0, 'Gold': 0, 'Other': 0 };
        
        const updated = await Promise.all(
          folios.map(async (f) => {
            try {
              const res = await fetch(`https://api.mfapi.in/mf/${f.schemeCode}`);
              const data = await res.json();
              
              let currentNav = 0;
              let currentValue = f.investedValue;
              
              if (data && data.data && data.data.length > 0) {
                currentNav = parseFloat(data.data[0].nav);
                currentValue = f.units * currentNav;
                
                // Categorize Asset
                const cat = (data.meta.scheme_category || '').toLowerCase();
                let type = 'Other';
                if (cat.match(/equity|index|large|mid|small|flexi|growth/i)) type = 'Equity';
                else if (cat.match(/debt|bond|liquid|overnight|gilt/i)) type = 'Debt';
                else if (cat.match(/hybrid|balanced|dynamic/i)) type = 'Hybrid';
                else if (cat.match(/gold|commodity/i)) type = 'Gold';
                
                allocationMap[type] += currentValue;
              }

              const returns = currentValue - f.investedValue;
              const returnsPercent = (returns / f.investedValue) * 100;

              return {
                ...f,
                currentNav,
                currentValue,
                returns,
                returnsPercent
              };
            } catch (err) {
              console.warn(`Failed to sync fund ${f.schemeCode}:`, err);
            }
            return { ...f, currentNav: 0, currentValue: f.investedValue, returns: 0, returnsPercent: 0 };
          })
        );

        setLiveFolios(updated);
        const totalVal = updated.reduce((sum, f) => sum + (f.currentValue || 0), 0);
        const totalInv = updated.reduce((sum, f) => sum + f.investedValue, 0);
        setPortfolioTotal(totalVal);
        setPortfolioInvested(totalInv);
        setPortfolioGain(totalVal - totalInv);

        // Calculate Asset Allocation Percentages
        const newAlloc = Object.entries(allocationMap)
            .filter(([_, val]) => val > 0)
            .map(([name, val]) => ({
                name,
                value: parseFloat(((val / totalVal) * 100).toFixed(1)),
                color: getAssetColor(name)
            }))
            .sort((a, b) => b.value - a.value);

        if (newAlloc.length > 0) {
            setAssetAllocation(newAlloc);
            setMaxAsset(newAlloc[0]);
        } else {
             // Fallback if value is 0 but folios exist (unlikely unless nav fetch fails)
            setAssetAllocation([{ name: 'Unknown', value: 100, color: '#94a3b8' }]);
            setMaxAsset({ name: 'Unknown', value: 0 });
        }

        if (folios.length > 0) {
          const chartRes = await fetch(`https://api.mfapi.in/mf/${folios[0].schemeCode}`);
          const chartJson = await chartRes.json();
          if (chartJson && chartJson.data) {
            const history = chartJson.data.slice(0, 30).reverse().map((d: any) => ({
              date: d.date.split("-").slice(0, 2).join("-"),
              nav: parseFloat(d.nav)
            }));
            setRealTimeChartData(history);
          }
        }
      } catch (err) {
        console.error("Failed to sync live data", err);
      } finally {
        setLoading(false);
      }
    };

    fetchRealTimeData();
  }, [folios]);

  const handleQuickTx = (e: React.MouseEvent, folioId: string, type: 'BUY' | 'SELL', nav: number) => {
    e.stopPropagation();
    e.preventDefault();
    if (!nav || nav <= 0) return;
    quickTransaction(folioId, type, nav);
  };

  const returnPercentage = portfolioInvested > 0 ? (portfolioGain / portfolioInvested) * 100 : 0;

  return (
    <div className="flex flex-col gap-6 relative">
      <div className="bg-gradient-to-br from-blue-600 to-blue-500 p-6 pt-8 pb-10 rounded-b-[40px] shadow-lg text-white">
        <div className="flex justify-between items-center mb-8 relative">
          <button onClick={() => setMenuOpen(true)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <Menu size={24} />
          </button>
          
          <div className="flex items-center gap-2">
            <div className="relative">
              <button 
                onClick={(e) => { e.stopPropagation(); setNotifOpen(!isNotifOpen); }} 
                className="relative p-2 hover:bg-white/10 rounded-full transition-colors"
              >
                <Bell size={24} />
                <span className="absolute top-2.5 right-2.5 w-2.5 h-2.5 bg-red-400 rounded-full border-2 border-blue-500"></span>
              </button>

              {isNotifOpen && (
                <div 
                  ref={notifRef}
                  className="absolute right-0 top-12 w-64 bg-white rounded-2xl shadow-2xl p-4 z-[110] border border-slate-100 animate-in fade-in zoom-in duration-200"
                  onClick={(e) => e.stopPropagation()}
                >
                  <h4 className="text-slate-800 font-bold text-xs mb-3">Recent Alerts</h4>
                  <div className="space-y-3">
                    {MOCK_NOTIFICATIONS.map(n => (
                      <div key={n.id} className="border-b border-slate-50 pb-2 last:border-0">
                        <p className="text-[11px] font-bold text-slate-800 leading-tight">{n.title}</p>
                        <p className="text-[10px] text-slate-400 mt-0.5">{n.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <Link to="/explore" className="p-2 hover:bg-white/10 rounded-full transition-colors relative">
              <ShoppingCart size={24} />
            </Link>

            <Link to="/profile">
              <img src={MOCK_USER.avatar} alt="Profile" className="w-10 h-10 rounded-full border-2 border-white/50" />
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="space-y-1">
            <p className="text-blue-100 text-[10px] font-bold uppercase tracking-wider">Net Portfolio Value</p>
            {loading ? <div className="h-8 w-32 bg-white/20 animate-pulse rounded" /> : (
              <h1 className="text-3xl font-bold">{formatCurrency(portfolioTotal)}</h1>
            )}
            <p className={`text-xs font-bold flex items-center gap-1 ${portfolioGain >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>
              {portfolioGain >= 0 ? '+' : ''}{formatCurrency(portfolioGain)} <ArrowUpRight size={14} />
            </p>
          </div>
          <div className="text-right space-y-1">
            <p className="text-blue-100 text-[10px] font-bold uppercase tracking-wider">Total Return %</p>
            <h2 className="text-lg font-bold text-white/90">
                {folios.length === 0 ? '0.00' : returnPercentage.toFixed(2)}%
            </h2>
            <div className="inline-flex items-center justify-center p-1 bg-white/20 rounded-md">
                <TrendingUp size={16} className={portfolioGain >= 0 ? "text-emerald-300" : "text-red-300"} />
            </div>
          </div>
        </div>

        <Link to="/assets" className="bg-white rounded-[32px] p-6 shadow-2xl text-slate-800 flex items-center justify-between hover:scale-[1.02] active:scale-[0.98] transition-all group overflow-hidden relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50/50 rounded-full translate-x-12 -translate-y-12 blur-2xl group-hover:bg-blue-100 transition-colors"></div>
          <div className="space-y-4 relative z-10">
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase mb-0.5">Asset Summary</p>
              <p className="text-slate-800 font-black text-sm">{maxAsset.name} Focus ({maxAsset.value}%)</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase mb-0.5">Invested Value</p>
              <p className="text-slate-500 font-bold text-sm">{formatCurrency(portfolioInvested)}</p>
            </div>
          </div>
          <div className="relative w-28 h-28 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie 
                  data={assetAllocation} 
                  innerRadius={30} 
                  outerRadius={44} 
                  dataKey="value" 
                  stroke="none" 
                  paddingAngle={5}
                >
                  {assetAllocation.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex items-center justify-center">
               <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center shadow-inner">
                  <TrendingUp size={16} className="text-blue-600" />
               </div>
            </div>
          </div>
        </Link>
      </div>

      <div className="px-6 space-y-4">
        <h3 className="font-bold text-slate-800 flex justify-between">My Holdings <span className="text-[10px] text-blue-600 font-black uppercase tracking-widest">Real-Time Sync</span></h3>
        {loading ? (
          [1, 2, 3].map(i => <div key={i} className="h-24 w-full bg-white rounded-3xl animate-pulse" />)
        ) : liveFolios.length === 0 ? (
          <div className="text-center py-10 bg-white rounded-3xl border border-dashed border-slate-200">
             <p className="text-slate-400 text-sm font-medium">No active investments.</p>
          </div>
        ) : (
          liveFolios.map((folio: any) => (
            <div 
              key={folio.id} 
              onClick={() => navigate(`/folio/${folio.id}`)}
              className="bg-white p-5 rounded-[28px] shadow-sm border border-slate-50 group hover:border-blue-100 transition-all cursor-pointer"
            >
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <h3 className="text-sm font-bold text-slate-800 line-clamp-1 group-hover:text-blue-600 transition-colors">{folio.schemeName}</h3>
                  <p className="text-[9px] text-slate-400 font-bold mt-1 uppercase tracking-tighter">Units: {folio.units.toFixed(2)}</p>
                </div>
                <div className="bg-slate-50 p-1.5 rounded-xl text-slate-300">
                  <ChevronRight size={16} />
                </div>
              </div>
              
              <div className="flex justify-between items-end">
                <div>
                  <span className="text-slate-800 font-black text-sm">{formatCurrency(folio.currentValue)}</span>
                  <span className={`text-[9px] font-black ml-2 ${(folio.returns || 0) >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                    {(folio.returns || 0) >= 0 ? '+' : ''}{folio.returnsPercent?.toFixed(2) ?? '0'}%
                  </span>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={(e) => handleQuickTx(e, folio.id, 'BUY', folio.currentNav)}
                    className="flex items-center justify-center gap-1 bg-emerald-50 text-emerald-600 px-3 py-1.5 rounded-xl font-black text-[9px] uppercase tracking-widest hover:bg-emerald-100 transition-colors"
                  >
                    <Plus size={12} /> Buy
                  </button>
                  <button 
                    onClick={(e) => handleQuickTx(e, folio.id, 'SELL', folio.currentNav)}
                    className="flex items-center justify-center gap-1 bg-red-50 text-red-600 px-3 py-1.5 rounded-xl font-black text-[9px] uppercase tracking-widest hover:bg-red-100 transition-colors"
                  >
                    <Minus size={12} /> Sell
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="px-6 pb-6">
        <div className="bg-white rounded-[32px] p-6 shadow-sm border border-slate-50">
          <h4 className="font-bold text-slate-800 mb-6 text-sm uppercase tracking-wider">Performance Trends</h4>
          <div className="h-48 w-full flex items-center justify-center">
            {loading ? <Loader2 className="animate-spin text-blue-600" /> : liveFolios.length === 0 ? <p className="text-slate-300 text-xs font-bold uppercase">No data to display</p> : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={realTimeChartData}>
                  <defs>
                    <linearGradient id="navGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f8fafc" />
                  <XAxis dataKey="date" hide />
                  <YAxis hide domain={['auto', 'auto']} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '10px' }} 
                  />
                  <Area type="monotone" dataKey="nav" stroke="#3b82f6" strokeWidth={3} fill="url(#navGradient)" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;