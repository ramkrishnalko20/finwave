
import React, { useState, useEffect } from 'react';
import { useParams, Link, useLocation, useSearchParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, MoreHorizontal, TrendingUp, History, Info, Loader2, ArrowUpRight, ArrowDownRight, ShoppingBag, Trash2, Minus, Plus, Calendar, X, CreditCard } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { usePortfolio } from '../PortfolioContext';

const PortfolioDetails: React.FC = () => {
  const { id, code } = useParams<{ id?: string; code?: string }>();
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { folios, removeFolio, sellUnits, investMore, addFolio, formatCurrency } = usePortfolio();
  const [schemeData, setSchemeData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [liveFolioData, setLiveFolioData] = useState<any>(null);

  const [isTransacting, setIsTransacting] = useState(false);
  const [txType, setTxType] = useState<'BUY' | 'SELL'>('BUY');
  const [amount, setAmount] = useState<string>("5000");
  const [investType, setInvestType] = useState<'SIP' | 'Lumpsum'>('Lumpsum');
  const [sipDate, setSipDate] = useState<number>(5);

  const folio = id ? folios.find(f => f.id === id) : folios.find(f => f.schemeCode === code);
  const targetCode = folio ? folio.schemeCode : code;

  useEffect(() => {
    const fetchDetails = async () => {
      if (!targetCode) return;
      setLoading(true);
      setSchemeData(null);
      setLiveFolioData(null);
      
      try {
        const res = await fetch(`https://api.mfapi.in/mf/${targetCode}`);
        const data = await res.json();
        
        if (!data || !data.data || data.data.length === 0) {
            throw new Error("No data found");
        }

        const chartData = [...data.data].reverse().slice(-100).map((d: any) => ({
          date: d.date,
          nav: parseFloat(d.nav)
        }));

        setSchemeData({
          meta: data.meta,
          chart: chartData
        });

        if (folio) {
            const latestNav = chartData[chartData.length - 1].nav;
            const currentValue = folio.units * latestNav;
            const returns = currentValue - folio.investedValue;
            setLiveFolioData({ currentValue, returns, latestNav });
            setInvestType(folio.investmentType);
            if (folio.sipDate) setSipDate(folio.sipDate);
        }
      } catch (err) {
        console.error("Failed to fetch details:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchDetails();
    window.scrollTo(0, 0);
  }, [targetCode, folio?.units]);

  useEffect(() => {
    const action = searchParams.get('action');
    if (action === 'buy' && !loading && schemeData) {
      setIsTransacting(true);
      setTxType('BUY');
    }
  }, [searchParams, loading, schemeData]);

  const handleConfirmTransaction = () => {
    const currentNav = schemeData.chart[schemeData.chart.length - 1]?.nav;
    if (!currentNav) return;

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) return;

    const units = numAmount / currentNav;

    if (txType === 'BUY') {
      if (!folio) {
        addFolio({ 
          schemeCode: targetCode!, 
          schemeName: schemeData.meta.scheme_name,
          planType: searchParams.get('plan') as 'Regular' | 'Direct' || 'Direct',
          investmentType: investType,
          amount: numAmount,
          units: units,
          sipDate: investType === 'SIP' ? sipDate : undefined
        });
      } else {
        investMore(folio.id, numAmount, units, investType, investType === 'SIP' ? sipDate : undefined);
      }
    } else {
      if (folio) {
        sellUnits(folio.id, units);
      }
    }

    setIsTransacting(false);
    navigate(location.pathname, { replace: true });
  };

  const openTx = (type: 'BUY' | 'SELL') => {
    setTxType(type);
    setIsTransacting(true);
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center h-screen gap-4 bg-white">
      <Loader2 className="animate-spin text-[#0059B2]" size={32} />
      <p className="text-slate-400 font-bold text-xs uppercase tracking-widest">Fetching Scheme Data...</p>
    </div>
  );

  if (!schemeData) return (
    <div className="p-8 text-center h-screen flex flex-col justify-center items-center gap-4">
        <div className="bg-red-50 text-red-500 p-4 rounded-full"><Info size={32} /></div>
        <h2 className="text-lg font-bold text-slate-800">Scheme Not Found</h2>
        <p className="text-slate-400 text-sm">We couldn't retrieve the details for this fund. Please try again later.</p>
        <Link to="/" className="text-blue-600 font-bold mt-4">Back to Home</Link>
    </div>
  );

  const currentNav = schemeData.chart[schemeData.chart.length - 1]?.nav;
  const previousNav = schemeData.chart[schemeData.chart.length - 2]?.nav;
  const isUp = currentNav >= (previousNav || 0);

  return (
    <div className="p-6 pb-12 animate-in fade-in duration-500 relative">
      <div className="flex justify-between items-center mb-8">
        <Link to={location.pathname.startsWith('/scheme') ? '/explore' : '/assets'} className="p-2 bg-slate-100 rounded-full text-slate-600 active:scale-90 transition-transform">
          <ChevronLeft size={20} />
        </Link>
        <div className="flex items-center gap-2">
            <span className="text-[9px] font-black text-slate-400 uppercase bg-slate-50 px-2 py-1 rounded-lg border border-slate-100">{schemeData.meta.fund_house}</span>
            {folio && (
              <button onClick={() => removeFolio(folio.id)} className="p-2 text-slate-300 hover:text-red-500 transition-colors">
                <Trash2 size={20} />
              </button>
            )}
            <button className="p-2 text-slate-300"><MoreHorizontal size={24} /></button>
        </div>
      </div>

      <div className="mb-8">
        <div className="flex gap-2 items-center mb-2">
            <span className="text-[10px] bg-[#0059B2] text-white px-2 py-0.5 rounded-lg font-bold uppercase tracking-tighter">{schemeData.meta.scheme_type}</span>
            <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-lg font-bold uppercase tracking-tighter">{schemeData.meta.scheme_category}</span>
            {folio && (
               <span className={`text-[10px] px-2 py-0.5 rounded-lg font-bold uppercase tracking-tighter ${folio.planType === 'Direct' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'}`}>
                 {folio.planType} Plan
               </span>
            )}
        </div>
        <h1 className="text-xl font-black text-slate-800 mb-1 leading-tight tracking-tight">{schemeData.meta.scheme_name}</h1>
        <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Fund Code: {schemeData.meta.scheme_code}</p>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-slate-50 p-5 rounded-3xl border border-slate-100 shadow-sm">
          <p className="text-[9px] text-slate-400 font-black uppercase mb-1 tracking-widest">Latest NAV</p>
          <div className="flex items-baseline gap-2">
            <p className="text-2xl font-black text-slate-800">{formatCurrency(currentNav)}</p>
            {previousNav && (
                <span className={`text-[10px] font-black flex items-center ${isUp ? 'text-emerald-500' : 'text-red-500'}`}>
                    {isUp ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
                    {Math.abs(((currentNav - previousNav) / previousNav) * 100).toFixed(2)}%
                </span>
            )}
          </div>
        </div>
        <div className="bg-blue-50 p-5 rounded-3xl border border-blue-100 shadow-sm">
          <p className="text-[9px] text-blue-600 font-black uppercase mb-1 tracking-widest">Risk Rating</p>
          <p className="text-2xl font-black text-blue-700">Moderate</p>
        </div>
      </div>

      <div className="bg-white rounded-[40px] border border-slate-50 p-8 shadow-sm mb-8">
        <h4 className="font-black text-[10px] text-slate-300 uppercase tracking-[0.2em] mb-8">Growth Analysis</h4>
        <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={schemeData.chart}>
                <defs>
                  <linearGradient id="colorNav" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0059B2" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#0059B2" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f8fafc" />
                <XAxis dataKey="date" hide />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#cbd5e1', fontWeight: 'bold' }} domain={['auto', 'auto']} />
                <Tooltip 
                    labelStyle={{ display: 'none' }}
                    contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', fontSize: '11px', fontWeight: 'bold' }} 
                />
                <Area type="monotone" dataKey="nav" stroke="#0059B2" strokeWidth={3} fillOpacity={1} fill="url(#colorNav)" />
              </AreaChart>
            </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-slate-900 rounded-[40px] p-8 shadow-xl space-y-6">
        {folio ? (
            <>
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <div className="bg-blue-500/20 p-2 rounded-xl"><TrendingUp size={18} className="text-blue-400" /></div>
                        <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Invested Amount</span>
                    </div>
                    <span className="font-black text-white">{formatCurrency(folio.investedValue)}</span>
                </div>
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <div className="bg-slate-500/20 p-2 rounded-xl"><History size={18} className="text-slate-300" /></div>
                        <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Current Value</span>
                    </div>
                    <span className="font-black text-white">{formatCurrency(liveFolioData?.currentValue)}</span>
                </div>
                <div className="flex justify-between items-center border-t border-slate-800 pt-6">
                    <div className="flex items-center gap-3">
                        <div className="bg-emerald-500/20 p-2 rounded-xl"><Info size={18} className="text-emerald-400" /></div>
                        <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Total Profit</span>
                    </div>
                    <span className="font-black text-emerald-400 text-lg">+{formatCurrency(liveFolioData?.returns)}</span>
                </div>
            </>
        ) : (
            <>
                <div className="flex justify-between items-center">
                    <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Min. Lumpsum</span>
                    <span className="font-black text-white">₹5,000.00</span>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Min. SIP</span>
                    <span className="font-black text-white">₹500.00</span>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Exit Load</span>
                    <span className="font-black text-white">1.00%</span>
                </div>
            </>
        )}
      </div>

      <div className="mt-8 flex flex-col gap-4">
        {folio ? (
          <div className="grid grid-cols-2 gap-4">
             <button 
                onClick={() => openTx('BUY')}
                className="bg-[#0059B2] text-white font-black py-5 rounded-[24px] shadow-xl shadow-blue-100 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Plus size={20} />
                Quick Buy
              </button>
              <button 
                onClick={() => openTx('SELL')}
                className="bg-slate-800 text-white font-black py-5 rounded-[24px] shadow-xl shadow-slate-100 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Minus size={20} />
                Quick Sell
              </button>
          </div>
        ) : (
          <button 
            onClick={() => openTx('BUY')}
            className="w-full bg-[#0059B2] text-white font-black py-5 rounded-[24px] shadow-xl shadow-blue-100 active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <ShoppingBag size={20} />
            Start Investing
          </button>
        )}
      </div>

      {isTransacting && (
        <div className="fixed inset-0 z-[150] flex items-end justify-center">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsTransacting(false)}></div>
          <div className="relative bg-white w-full max-w-md rounded-t-[40px] p-8 shadow-2xl animate-in slide-in-from-bottom duration-300 max-h-[90vh] overflow-y-auto no-scrollbar">
             <div className="w-12 h-1 bg-slate-100 rounded-full mx-auto mb-6 shrink-0"></div>
             
             <div className="flex justify-between items-center mb-8 shrink-0">
                <div>
                   <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">{txType === 'BUY' ? 'Invest in' : 'Redeem from'} Fund</h2>
                   <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Confirm your details</p>
                </div>
                <button onClick={() => setIsTransacting(false)} className="p-2 bg-slate-50 text-slate-400 rounded-full"><X size={20} /></button>
             </div>

             <div className="space-y-6">
                <div>
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Investment Amount (₹)</label>
                    <div className="relative">
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-slate-400">₹</span>
                        <input 
                            type="number"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            placeholder="Enter amount"
                            className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-8 pr-4 text-slate-800 font-black outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                        />
                    </div>
                </div>

                {txType === 'BUY' && (
                    <>
                        <div>
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Investment Type</label>
                            <div className="flex bg-slate-100 p-1 rounded-2xl">
                                <button 
                                    onClick={() => setInvestType('Lumpsum')}
                                    className={`flex-1 py-3 rounded-xl font-black text-xs transition-all ${investType === 'Lumpsum' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
                                >
                                    Lumpsum
                                </button>
                                <button 
                                    onClick={() => setInvestType('SIP')}
                                    className={`flex-1 py-3 rounded-xl font-black text-xs transition-all ${investType === 'SIP' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
                                >
                                    Monthly SIP
                                </button>
                            </div>
                        </div>

                        {investType === 'SIP' && (
                            <div className="animate-in fade-in slide-in-from-top-2 duration-300">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2 flex items-center gap-2">
                                    <Calendar size={12} /> Monthly SIP Date
                                </label>
                                <select 
                                    value={sipDate}
                                    onChange={(e) => setSipDate(parseInt(e.target.value))}
                                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 px-4 text-slate-800 font-black outline-none focus:ring-2 focus:ring-blue-500 appearance-none transition-all cursor-pointer"
                                >
                                    {Array.from({ length: 28 }, (_, i) => i + 1).map(day => (
                                        <option key={day} value={day}>{day} of every month</option>
                                    ))}
                                </select>
                            </div>
                        )}
                    </>
                )}

                <div className="bg-blue-50 p-6 rounded-[32px] border border-blue-100">
                    <div className="flex justify-between items-center mb-2">
                        <span className="text-[10px] font-black text-blue-400 uppercase">Estimated Units</span>
                        <span className="text-sm font-black text-blue-700">
                            {(parseFloat(amount) / (currentNav || 1)).toFixed(4)}
                        </span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black text-blue-400 uppercase">Transaction Fee</span>
                        <span className="text-sm font-black text-blue-700">₹0.00</span>
                    </div>
                </div>

                <div className="flex gap-4 pt-4">
                    <button 
                        onClick={() => setIsTransacting(false)}
                        className="flex-1 py-4 bg-slate-100 text-slate-500 font-black rounded-2xl uppercase text-[10px] tracking-widest active:scale-95 transition-all"
                    >
                        Cancel
                    </button>
                    <button 
                        onClick={handleConfirmTransaction}
                        className="flex-[2] py-4 bg-[#0059B2] text-white font-black rounded-2xl uppercase text-[10px] tracking-widest shadow-xl shadow-blue-100 active:scale-95 transition-all flex items-center justify-center gap-2"
                    >
                        <CreditCard size={14} />
                        Confirm {txType === 'BUY' ? (investType === 'SIP' ? 'Start SIP' : 'Invest') : 'Redeem'}
                    </button>
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PortfolioDetails;
