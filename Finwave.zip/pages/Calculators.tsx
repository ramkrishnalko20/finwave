
import React, { useState } from 'react';
import { 
  TrendingUp, Wallet, RockingChair, ChevronLeft, Info, Landmark, 
  History, Percent, Timer, Heart, GraduationCap, Coins, X, 
  ArrowRight, Calculator as CalcIcon, Download, Loader2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { usePortfolio } from '../PortfolioContext';

const CALC_CARDS = [
  { id: 'sip', name: 'SIP', icon: TrendingUp, color: 'bg-blue-600', textColor: 'text-white', category: 'Investing' },
  { id: 'emi', name: 'EMI', icon: Percent, color: 'bg-emerald-500', textColor: 'text-white', category: 'Loans' },
  { id: 'delay', name: 'Delay Cost', icon: Timer, color: 'bg-amber-500', textColor: 'text-white', category: 'Insight' },
  { id: 'child', name: 'Child Future', icon: Heart, color: 'bg-rose-500', textColor: 'text-white', category: 'Goals' },
  { id: 'lumpsum', name: 'Lumpsum', icon: Wallet, color: 'bg-indigo-500', textColor: 'text-white', category: 'Investing' },
  { id: 'fd', name: 'Fixed Deposit', icon: Landmark, color: 'bg-slate-700', textColor: 'text-white', category: 'Savings' },
  { id: 'stp', name: 'STP', icon: ArrowRight, color: 'bg-violet-500', textColor: 'text-white', category: 'Transfers' },
  { id: 'swp', name: 'SWP', icon: History, color: 'bg-orange-500', textColor: 'text-white', category: 'Withdrawal' },
  { id: 'retirement', name: 'Retirement', icon: RockingChair, color: 'bg-cyan-600', textColor: 'text-white', category: 'Goals' },
  { id: 'fv', name: 'Future Value', icon: Coins, color: 'bg-teal-600', textColor: 'text-white', category: 'Investing' },
  { id: 'loan', name: 'Loan Payoff', icon: CalcIcon, color: 'bg-zinc-800', textColor: 'text-white', category: 'Loans' },
  { id: 'ppf', name: 'PPF', icon: Landmark, color: 'bg-emerald-700', textColor: 'text-white', category: 'Savings' },
];

const Calculators: React.FC = () => {
  const [selectedCalc, setSelectedCalc] = useState<string | null>(null);

  return (
    <div className="p-6 pb-24">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <Link to="/" className="p-2 bg-white shadow-sm border border-slate-100 rounded-xl text-slate-600 active:scale-90 transition-transform">
            <ChevronLeft size={20} />
          </Link>
          <h1 className="text-2xl font-black text-slate-800 tracking-tight">FinTools</h1>
        </div>
        <div className="bg-blue-50 px-3 py-1 rounded-lg">
          <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">v2.1 Pro</span>
        </div>
      </div>

      <p className="text-slate-400 font-bold text-[10px] uppercase tracking-[0.2em] mb-6">Investment & Planning Suite</p>

      <div className="grid grid-cols-2 gap-4 mb-10">
        {CALC_CARDS.map((card) => (
          <button 
            key={card.id}
            onClick={() => setSelectedCalc(card.id)}
            className={`${card.color} rounded-[32px] p-5 flex flex-col justify-between items-start transition-all active:scale-95 shadow-xl shadow-slate-200/50 hover:brightness-110 h-40 group text-left`}
          >
            <div className="flex justify-between w-full items-start">
              <div className="p-3 rounded-2xl bg-white/20 backdrop-blur-sm text-white">
                <card.icon size={24} />
              </div>
              <span className="text-[8px] font-black uppercase tracking-widest text-white/60">{card.category}</span>
            </div>
            <div>
              <span className="text-white font-black text-lg leading-tight block">{card.name}</span>
              <span className="text-[9px] text-white/50 font-bold uppercase tracking-tighter">Calculator</span>
            </div>
          </button>
        ))}
      </div>

      {selectedCalc && (
        <GenericCalcModal type={selectedCalc} onClose={() => setSelectedCalc(null)} />
      )}

      <div className="bg-slate-900 rounded-[32px] p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/20 blur-3xl rounded-full translate-x-10 -translate-y-10"></div>
        <div className="relative z-10">
          <div className="flex gap-3 mb-4">
            <div className="bg-blue-600 p-2 rounded-xl h-fit shadow-lg"><Info size={20} className="text-white" /></div>
            <h4 className="font-black text-white text-sm uppercase tracking-wider mt-1">Smart Planning Advice</h4>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed font-medium mb-6">
            Always account for an annual inflation rate of <span className="text-white font-bold">6%</span> and relevant tax implications (LTCG/STCG) to see your actual purchasing power in the future.
          </p>
          <button className="w-full bg-white/10 hover:bg-white/20 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-colors">
            Learn about Compound Interest
          </button>
        </div>
      </div>
    </div>
  );
};

const GenericCalcModal: React.FC<{ type: string; onClose: () => void }> = ({ type, onClose }) => {
  const { formatCurrency } = usePortfolio();
  const [p, setP] = useState(100000); 
  const [r, setR] = useState(12); 
  const [t, setT] = useState(10); 
  const [extra, setExtra] = useState(5000); 
  const [saving, setSaving] = useState(false);

  const calculateResult = () => {
    switch(type) {
      case 'sip': {
        const i = r / 12 / 100;
        const n = t * 12;
        const fv = p * ((Math.pow(1 + i, n) - 1) / i) * (1 + i);
        return { label: 'Future Value', value: Math.round(fv), info: 'Total wealth after tenure' };
      }
      case 'emi': {
        const i = r / 12 / 100;
        const n = t * 12;
        const emi = p * i * (Math.pow(1 + i, n) / (Math.pow(1 + i, n) - 1));
        return { label: 'Monthly EMI', value: Math.round(emi), info: 'Per month installment' };
      }
      case 'delay': {
        const i = r / 12 / 100;
        const nFull = t * 12;
        const nDelayed = (t - extra/12) * 12; 
        const fv1 = p * ((Math.pow(1 + i, nFull) - 1) / i) * (1 + i);
        const fv2 = p * ((Math.pow(1 + i, nDelayed) - 1) / i) * (1 + i);
        return { label: 'Cost of Delay', value: Math.max(0, Math.round(fv1 - fv2)), info: 'Wealth lost by waiting' };
      }
      case 'child': {
        const inflation = 6 / 100;
        const futureGoal = p * Math.pow(1 + inflation, t);
        return { label: 'Required Fund', value: Math.round(futureGoal), info: 'Inflation adjusted cost' };
      }
      case 'lumpsum': {
        const fv = p * Math.pow(1 + (r / 100), t);
        return { label: 'Wealth Gained', value: Math.round(fv), info: 'Maturity value' };
      }
      case 'fd': {
        const fv = p * Math.pow(1 + (r / 100) / 4, 4 * t);
        return { label: 'Maturity Value', value: Math.round(fv), info: 'Quarterly compounding' };
      }
      case 'stp': {
        const iTarget = r / 100 / 12;
        const months = t * 12;
        const fvTarget = extra * ((Math.pow(1 + iTarget, months) - 1) / iTarget) * (1 + iTarget);
        return { label: 'Final Corpus', value: Math.round(fvTarget), info: 'Value in Target Fund' };
      }
      case 'swp': {
        const i = r / 12 / 100;
        const n = t * 12;
        const fv = p * Math.pow(1 + i, n) - extra * ((Math.pow(1 + i, n) - 1) / i);
        return { label: 'Residual Value', value: Math.max(0, Math.round(fv)), info: 'Balance after tenure' };
      }
      case 'retirement': {
        const currentExp = p * 12;
        const inflation = 6 / 100;
        const fvExp = currentExp * Math.pow(1 + inflation, t);
        const corpusNeeded = fvExp / 0.06; 
        return { label: 'Target Corpus', value: Math.round(corpusNeeded), info: 'For life-long income' };
      }
      case 'fv': {
        const fv = p * Math.pow(1 + (r / 100), t);
        return { label: 'Future Value', value: Math.round(fv), info: 'Compound value' };
      }
      case 'loan': {
        const i = r / 12 / 100;
        const n = t * 12;
        const emi = p * i * (Math.pow(1 + i, n) / (Math.pow(1 + i, n) - 1));
        const totalPayable = emi * n;
        return { label: 'Total Interest', value: Math.round(totalPayable - p), info: 'Extra paid to bank' };
      }
      case 'ppf': {
        const rate = 7.1 / 100;
        const fv = p * ((Math.pow(1 + rate, t) - 1) / rate) * (1 + rate);
        return { label: 'Maturity', value: Math.round(fv), info: 'Tax-free returns' };
      }
      default: return { label: 'Result', value: 0, info: '' };
    }
  };

  const result = calculateResult();

  const handleSaveReport = () => {
    setSaving(true);
    const labels = getLabels();
    const reportText = `
FINWAVE FINANCIAL PLANNING REPORT
----------------------------------
Calculator Type: ${type.toUpperCase()}
Date: ${new Date().toLocaleDateString()}

INPUT PARAMETERS:
- ${labels.p}: ${formatCurrency(p)}
${labels.r ? `- ${labels.r}: ${r}%` : ''}
- ${labels.t}: ${t} Years
${labels.e ? `- ${labels.e}: ${type === 'delay' ? extra + ' Months' : formatCurrency(extra)}` : ''}

PROJECTION SUMMARY:
- ${result.label}: ${formatCurrency(result.value)}
- Note: ${result.info}

Disclaimer: This report is an estimation based on standard financial formulas. Actual market returns may vary.
----------------------------------
Generated by Finwave - Your Wealth Identity
    `.trim();

    const blob = new Blob([reportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Finwave_${type.toUpperCase()}_Report.txt`;
    
    setTimeout(() => {
      link.click();
      URL.revokeObjectURL(url);
      setSaving(false);
    }, 1000);
  };

  const getLabels = () => {
    switch(type) {
      case 'emi': return { p: 'Loan Amount', r: 'Interest Rate (%)', t: 'Tenure (Yrs)', e: null };
      case 'delay': return { p: 'Monthly SIP', r: 'Expected Return (%)', t: 'Target Tenure (Yrs)', e: 'Delay in Months' };
      case 'child': return { p: 'Today\'s Cost', r: null, t: 'Years to Goal', e: null };
      case 'stp': return { p: 'Lumpsum in Source', r: 'Target Fund Return (%)', t: 'Transfer Period (Yrs)', e: 'Monthly Transfer' };
      case 'swp': return { p: 'Total Corpus', r: 'Expected Return (%)', t: 'Withdrawal Period (Yrs)', e: 'Monthly Withdrawal' };
      case 'retirement': return { p: 'Current Monthly Expense', r: null, t: 'Years to Retirement', e: null };
      default: return { p: 'Principal / Monthly', r: 'Expected Return (%)', t: 'Time Period (Yrs)', e: null };
    }
  };

  const labels = getLabels();

  return (
    <div className="fixed inset-0 z-[120] flex items-end justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-white w-full max-w-md rounded-t-[40px] p-8 shadow-2xl animate-in slide-in-from-bottom duration-300 max-h-[90vh] overflow-y-auto no-scrollbar">
        <div className="w-12 h-1 bg-slate-100 rounded-full mx-auto mb-6 shrink-0"></div>
        
        <div className="flex justify-between items-center mb-8 shrink-0">
          <div>
            <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">{type} Pro Planner</h2>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Financial Projection</p>
          </div>
          <button onClick={onClose} className="p-2 bg-slate-50 text-slate-400 rounded-full hover:text-slate-600 transition-colors"><X size={20} /></button>
        </div>

        <div className="space-y-8">
          <div>
            <div className="flex justify-between mb-3 items-end">
              <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest">{labels.p}</label>
              <span className="text-blue-600 font-black text-lg">{formatCurrency(p)}</span>
            </div>
            <input 
              type="range" 
              min={type === 'retirement' ? "5000" : "500"} 
              max={type === 'emi' ? "10000000" : "2000000"} 
              step="500" 
              value={p} 
              onChange={(e) => setP(Number(e.target.value))} 
              className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600" 
            />
          </div>

          {labels.e && (
            <div>
              <div className="flex justify-between mb-3 items-end">
                <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest">{labels.e}</label>
                <span className="text-blue-600 font-black text-lg">
                  {type === 'delay' ? `${extra} Mon` : formatCurrency(extra)}
                </span>
              </div>
              <input 
                type="range" 
                min={type === 'delay' ? "1" : "500"} 
                max={type === 'delay' ? "120" : "100000"} 
                step={type === 'delay' ? "1" : "500"} 
                value={extra} 
                onChange={(e) => setExtra(Number(e.target.value))} 
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600" 
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-6">
            {labels.r && (
              <div>
                <label className="text-[10px] font-black text-slate-400 block mb-2 uppercase tracking-widest">{labels.r}</label>
                <div className="relative">
                  <input 
                    type="number" 
                    value={r} 
                    onChange={(e) => setR(Number(e.target.value))} 
                    className="w-full bg-slate-50 p-4 rounded-2xl font-black text-slate-800 outline-none border border-slate-100 focus:border-blue-300 transition-colors" 
                  />
                  <Percent size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" />
                </div>
              </div>
            )}
            <div>
              <label className="text-[10px] font-black text-slate-400 block mb-2 uppercase tracking-widest">{labels.t}</label>
              <div className="relative">
                <input 
                  type="number" 
                  value={t} 
                  onChange={(e) => setT(Number(e.target.value))} 
                  className="w-full bg-slate-50 p-4 rounded-2xl font-black text-slate-800 outline-none border border-slate-100 focus:border-blue-300 transition-colors" 
                />
                <Timer size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" />
              </div>
            </div>
          </div>

          <div className="bg-blue-600 rounded-[32px] p-8 text-center text-white shadow-2xl shadow-blue-100 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent pointer-events-none"></div>
            <p className="text-[10px] opacity-80 font-black uppercase tracking-[0.2em] mb-2">{result.label}</p>
            <h3 className="text-4xl font-black tracking-tighter mb-2 scale-100 group-hover:scale-110 transition-transform">{formatCurrency(result.value)}</h3>
            <p className="text-[9px] font-bold text-blue-100 uppercase tracking-widest opacity-60 italic">{result.info}</p>
          </div>

          <div className="flex gap-4">
            <button 
              onClick={handleSaveReport} 
              disabled={saving}
              className="flex-1 bg-slate-100 text-slate-600 font-black py-4 rounded-2xl uppercase text-[10px] tracking-widest active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              {saving ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
              {saving ? 'Saving...' : 'Save Report'}
            </button>
            <button onClick={onClose} className="flex-1 bg-slate-800 text-white font-black py-4 rounded-2xl uppercase text-[10px] tracking-widest active:scale-95 transition-all">
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Calculators;
