
import React, { useState, useEffect } from 'react';
import { Search, ArrowUpRight, ShieldCheck, Loader2, ShoppingCart, X, Trash2, CheckCircle2, ShoppingBag, AlertCircle, ChevronLeft } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { usePortfolio } from '../PortfolioContext';

interface SchemeAPI {
  schemeCode: number;
  schemeName: string;
}

interface CartItem {
  schemeCode: number;
  schemeName: string;
  planType: 'Regular' | 'Direct';
}

const Explore: React.FC = () => {
  const [schemes, setSchemes] = useState<SchemeAPI[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  
  // Local state to track chosen plan per scheme code for the listing
  const [tempPlans, setTempPlans] = useState<Record<number, 'Regular' | 'Direct'>>({});

  const navigate = useNavigate();
  const { addFolio } = usePortfolio();

  useEffect(() => {
    const fetchAllSchemes = async () => {
      try {
        const response = await fetch('https://api.mfapi.in/mf');
        const data = await response.json();
        setSchemes(data.slice(0, 1000));
      } catch (error) {
        console.error("Failed to fetch schemes", error);
      } finally {
        setLoading(false);
      }
    };
    fetchAllSchemes();
  }, []);

  const filteredSchemes = schemes.filter(scheme => 
    scheme.schemeName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    scheme.schemeCode.toString().includes(searchTerm)
  );

  const showToast = (message: string) => {
    setToast(message);
    setTimeout(() => setToast(null), 2500);
  };

  const handleAddToCart = (e: React.MouseEvent, scheme: SchemeAPI) => {
    e.stopPropagation();
    const plan = tempPlans[scheme.schemeCode] || 'Direct';
    if (cart.find(item => item.schemeCode === scheme.schemeCode)) {
      showToast("Already in your cart!");
      return;
    }
    setCart(prev => [...prev, { ...scheme, planType: plan }]);
    showToast(`Added ${plan} Plan to cart`);
  };

  const removeFromCart = (code: number) => {
    setCart(prev => prev.filter(item => item.schemeCode !== code));
  };

  const confirmInvestments = () => {
    if (cart.length === 0) return;
    const firstItem = cart[0];
    cart.forEach((item) => {
      if (item.schemeCode !== firstItem.schemeCode) {
        addFolio({ 
          schemeCode: item.schemeCode.toString(), 
          schemeName: item.schemeName,
          planType: item.planType
        });
      }
    });
    const targetCode = firstItem.schemeCode;
    const targetPlan = firstItem.planType;
    setCart([]);
    setIsCartOpen(false);
    navigate(`/scheme/${targetCode}?action=buy&plan=${targetPlan}`);
  };

  const togglePlan = (e: React.MouseEvent, code: number) => {
    e.stopPropagation();
    setTempPlans(prev => ({
      ...prev,
      [code]: prev[code] === 'Regular' ? 'Direct' : 'Regular'
    }));
  };

  return (
    <div className="p-6 relative">
      {toast && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[200] animate-in slide-in-from-top duration-300">
          <div className="bg-slate-900/90 backdrop-blur-md text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 border border-white/10">
            <AlertCircle size={16} className="text-blue-400" />
            <span className="text-xs font-black uppercase tracking-widest">{toast}</span>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-3">
          <Link to="/" className="p-2 bg-slate-100 rounded-full text-slate-600 active:scale-90 transition-transform">
            <ChevronLeft size={20} />
          </Link>
          <h1 className="text-2xl font-black text-slate-800 tracking-tight">Explore Funds</h1>
        </div>
        <button 
          onClick={() => setIsCartOpen(true)}
          className="relative p-2.5 bg-white shadow-lg shadow-slate-100 rounded-2xl text-slate-600 border border-slate-50 active:scale-90 transition-all"
        >
          <ShoppingCart size={22} />
          {cart.length > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-600 text-white text-[10px] font-black flex items-center justify-center rounded-full border-2 border-white animate-in zoom-in">
              {cart.length}
            </span>
          )}
        </button>
      </div>
      
      <div className="relative mb-6">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
        <input 
          type="text"
          placeholder="Search funds (e.g. HDFC, Axis)..."
          className="w-full bg-slate-100 border-none rounded-2xl py-4 pl-12 pr-4 text-slate-700 font-bold outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-slate-300"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="flex gap-3 mb-8 overflow-x-auto no-scrollbar pb-2">
        {['All Funds', 'Equity', 'Debt', 'Hybrid', 'Small Cap', 'Bluechip'].map((cat) => (
          <button 
            key={cat}
            className="px-5 py-2 rounded-full text-[10px] font-black whitespace-nowrap bg-white border border-slate-100 text-slate-400 hover:border-blue-500 hover:text-blue-600 transition-all uppercase tracking-widest"
          >
            {cat}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Loader2 className="animate-spin text-blue-600" size={32} />
          <p className="text-slate-400 font-bold animate-pulse text-[10px] uppercase tracking-widest">Fetching real-time funds...</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredSchemes.map(scheme => {
            const isInCart = cart.some(item => item.schemeCode === scheme.schemeCode);
            const selectedPlan = tempPlans[scheme.schemeCode] || 'Direct';
            return (
              <div 
                key={scheme.schemeCode} 
                onClick={() => navigate(`/scheme/${scheme.schemeCode}?plan=${selectedPlan}`)}
                className="w-full text-left bg-white p-5 rounded-[28px] border border-slate-50 shadow-sm hover:shadow-md transition-all active:scale-[0.99] cursor-pointer group"
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1 pr-4">
                    <h3 className="font-bold text-slate-800 text-sm mb-1.5 leading-tight group-hover:text-blue-600 transition-colors">{scheme.schemeName}</h3>
                    <div className="flex flex-wrap gap-2">
                      <span className="text-[9px] bg-slate-50 text-slate-500 px-2 py-0.5 rounded-lg font-black uppercase tracking-tighter">Code: {scheme.schemeCode}</span>
                      <span className={`text-[9px] px-2 py-0.5 rounded-lg font-black uppercase tracking-tighter ${selectedPlan === 'Direct' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'}`}>
                        {selectedPlan}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <ArrowUpRight size={18} className="text-slate-200 group-hover:text-blue-400 ml-auto transition-colors" />
                  </div>
                </div>
                
                <div className="flex justify-between items-center pt-4 border-t border-slate-50">
                  <div 
                    onClick={(e) => togglePlan(e, scheme.schemeCode)}
                    className="flex bg-slate-100 p-1 rounded-full text-[9px] font-black"
                  >
                    <button className={`px-3 py-1 rounded-full transition-all ${selectedPlan === 'Direct' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}>DIRECT</button>
                    <button className={`px-3 py-1 rounded-full transition-all ${selectedPlan === 'Regular' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}>REGULAR</button>
                  </div>
                  <button 
                    onClick={(e) => handleAddToCart(e, scheme)}
                    className={`text-[10px] font-black px-6 py-2 rounded-full transition-all uppercase tracking-widest ${
                      isInCart 
                      ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' 
                      : 'bg-[#0059B2] text-white shadow-lg shadow-blue-100 active:scale-90'
                    }`}
                  >
                    {isInCart ? 'In Cart' : 'Add to Cart'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Cart Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 z-[120] flex items-end justify-center">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setIsCartOpen(false)}></div>
          <div className="relative bg-white w-full max-w-md rounded-t-[40px] p-8 shadow-2xl animate-in slide-in-from-bottom duration-300 max-h-[85vh] flex flex-col">
            <div className="w-12 h-1 bg-slate-200 rounded-full mx-auto mb-6 shrink-0"></div>
            
            <div className="flex justify-between items-center mb-8 shrink-0">
              <div>
                <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">Investment Cart</h2>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{cart.length} Schemes selected</p>
              </div>
              <button onClick={() => setIsCartOpen(false)} className="p-2 bg-slate-100 rounded-full text-slate-400"><X size={20} /></button>
            </div>

            <div className="flex-1 overflow-y-auto no-scrollbar space-y-4 pr-1">
              {cart.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingBag size={32} className="text-slate-200 mx-auto mb-4" />
                  <p className="text-slate-400 font-bold text-sm">Your cart is empty.</p>
                </div>
              ) : (
                cart.map((item) => (
                  <div key={item.schemeCode} className="flex items-center gap-4 bg-slate-50 p-4 rounded-3xl border border-slate-100 group">
                    <div className="flex-1">
                      <h4 className="font-bold text-slate-800 text-xs leading-tight mb-1">{item.schemeName}</h4>
                      <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                        {item.planType} Plan • Code: {item.schemeCode}
                      </p>
                    </div>
                    <button 
                      onClick={() => removeFromCart(item.schemeCode)}
                      className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="pt-8 border-t border-slate-50 mt-4 shrink-0">
                <div className="flex gap-4">
                  <button 
                    onClick={() => setIsCartOpen(false)} 
                    className="flex-1 bg-slate-100 text-slate-600 font-black py-4 rounded-2xl uppercase text-[10px] tracking-widest active:scale-95 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={confirmInvestments} 
                    className="flex-2 bg-[#0059B2] text-white font-black py-4 px-8 rounded-2xl uppercase text-[10px] tracking-widest shadow-xl shadow-blue-100 active:scale-95 transition-all flex items-center justify-center gap-2"
                  >
                    Confirm Investment
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Explore;
