import React, { useState } from 'react';
import { 
  User, 
  Settings, 
  Shield, 
  HelpCircle, 
  LogOut, 
  ChevronRight,
  BellRing,
  CreditCard,
  History,
  ChevronLeft,
  Phone,
  Mail,
  Globe,
  MapPin,
  Plus,
  X,
  Check,
  Lock,
  Smartphone,
  Key,
  Moon,
  Globe2,
  Trash2,
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { MOCK_USER } from '../constants';
import { useNavigate, Link } from 'react-router-dom';

const Account: React.FC<{ onLogout: () => void }> = ({ onLogout }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<string | null>(null);

  // --- Local State for features ---
  
  // Banks
  const [banks, setBanks] = useState([
    { id: 1, name: 'State Bank of India', account: '**** **** 1234', ifsc: 'SBIN0001234', primary: true }
  ]);
  const [showAddBank, setShowAddBank] = useState(false);
  const [newBank, setNewBank] = useState({ name: '', account: '', ifsc: '' });

  // Notifications
  const [notifs, setNotifs] = useState({
    push: true,
    email: false,
    promo: false,
    portfolio: true
  });

  // Security
  const [security, setSecurity] = useState({
    biometric: true,
    twoFactor: false
  });

  const menuItems = [
    { id: 'profile', icon: User, label: 'Profile Information', color: 'text-blue-500', bg: 'bg-blue-50', path: '/profile' },
    { id: 'banks', icon: CreditCard, label: 'Linked Bank Accounts', color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { id: 'notifs', icon: BellRing, label: 'Notification Preferences', color: 'text-orange-500', bg: 'bg-orange-50' },
    { id: 'history', icon: History, label: 'Transaction History', color: 'text-purple-500', bg: 'bg-purple-50' },
    { id: 'security', icon: Shield, label: 'Security & Privacy', color: 'text-red-500', bg: 'bg-red-50' },
    { id: 'settings', icon: Settings, label: 'App Settings', color: 'text-slate-500', bg: 'bg-slate-50' },
    { id: 'support', icon: HelpCircle, label: 'Help & Support', color: 'text-indigo-500', bg: 'bg-indigo-50' },
  ];

  const handleAddBank = () => {
    if (newBank.name && newBank.account) {
      setBanks([...banks, { 
        id: Date.now(), 
        name: newBank.name, 
        account: `**** **** ${newBank.account.slice(-4)}`, 
        ifsc: newBank.ifsc.toUpperCase(),
        primary: false 
      }]);
      setNewBank({ name: '', account: '', ifsc: '' });
      setShowAddBank(false);
    }
  };

  const toggleNotif = (key: keyof typeof notifs) => {
    setNotifs(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleSecurity = (key: keyof typeof security) => {
    setSecurity(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const renderTabContent = (id: string) => {
    switch (id) {
      case 'banks':
        return (
          <div className="space-y-4 relative">
            {banks.map((bank) => (
              <div key={bank.id} className="bg-white p-5 rounded-3xl border border-slate-100 flex justify-between items-center shadow-sm">
                <div className="flex gap-4 items-center">
                  <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center font-bold text-slate-600 text-xs">
                    {bank.name.slice(0, 3).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-black text-slate-800 text-sm">{bank.name}</p>
                    <p className="text-[10px] text-slate-400 font-bold">{bank.account}</p>
                  </div>
                </div>
                {bank.primary && (
                  <div className="bg-emerald-100 text-emerald-600 text-[9px] px-2 py-1 rounded-lg font-black uppercase tracking-wider">Primary</div>
                )}
              </div>
            ))}
            
            <button 
              onClick={() => setShowAddBank(true)}
              className="w-full py-4 border-2 border-dashed border-slate-200 text-slate-400 font-bold rounded-3xl hover:bg-slate-50 transition-colors flex items-center justify-center gap-2 active:scale-98"
            >
              <Plus size={18} /> Add New Account
            </button>

            {showAddBank && (
              <div className="fixed inset-0 z-[150] flex items-end justify-center">
                <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowAddBank(false)}></div>
                <div className="relative bg-white w-full max-w-md rounded-t-[40px] p-8 shadow-2xl animate-in slide-in-from-bottom duration-300">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-black text-slate-800">Link Bank Account</h3>
                    <button onClick={() => setShowAddBank(false)} className="p-2 bg-slate-50 rounded-full"><X size={20} className="text-slate-400" /></button>
                  </div>
                  <div className="space-y-4">
                    <input 
                      placeholder="Bank Name" 
                      className="w-full bg-slate-50 p-4 rounded-2xl font-bold text-slate-800 outline-none border border-transparent focus:border-blue-500 transition-all"
                      value={newBank.name}
                      onChange={e => setNewBank({...newBank, name: e.target.value})}
                    />
                    <input 
                      placeholder="Account Number" 
                      type="number"
                      className="w-full bg-slate-50 p-4 rounded-2xl font-bold text-slate-800 outline-none border border-transparent focus:border-blue-500 transition-all"
                      value={newBank.account}
                      onChange={e => setNewBank({...newBank, account: e.target.value})}
                    />
                    <input 
                      placeholder="IFSC Code" 
                      className="w-full bg-slate-50 p-4 rounded-2xl font-bold text-slate-800 outline-none border border-transparent focus:border-blue-500 transition-all uppercase"
                      value={newBank.ifsc}
                      onChange={e => setNewBank({...newBank, ifsc: e.target.value})}
                    />
                    <button 
                      onClick={handleAddBank}
                      className="w-full bg-blue-600 text-white font-black py-4 rounded-2xl uppercase text-xs tracking-widest shadow-lg shadow-blue-200 active:scale-95 transition-all mt-4"
                    >
                      Verify & Link Account
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        );

      case 'history':
        return (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="bg-white p-4 rounded-2xl flex justify-between items-center border border-slate-50">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-50 p-2 rounded-xl text-blue-600">
                    <RefreshCw size={16} />
                  </div>
                  <div>
                    <p className="font-bold text-xs text-slate-800">SIP Installment</p>
                    <p className="text-[9px] text-slate-400 font-bold">24 Oct, 2023 • Successful</p>
                  </div>
                </div>
                <p className="font-black text-slate-800 text-xs">-₹5,000</p>
              </div>
            ))}
            <button className="w-full py-3 text-[10px] font-black text-blue-600 uppercase tracking-widest bg-blue-50 rounded-xl mt-2">
              View All Transactions
            </button>
          </div>
        );

      case 'notifs':
        return (
          <div className="space-y-4">
            <div className="bg-white rounded-[24px] border border-slate-50 overflow-hidden">
              {[
                { key: 'push', label: 'Push Notifications', desc: 'Receive alerts on your device' },
                { key: 'email', label: 'Email Alerts', desc: 'Get summaries and statements' },
                { key: 'portfolio', label: 'Portfolio Updates', desc: 'Daily NAV and valuation reports' },
                { key: 'promo', label: 'Promotional Offers', desc: 'News about new features' },
              ].map((item, idx) => (
                <div key={item.key} className={`p-5 flex justify-between items-center ${idx !== 3 ? 'border-b border-slate-50' : ''}`}>
                  <div>
                    <p className="font-bold text-slate-800 text-sm">{item.label}</p>
                    <p className="text-[10px] text-slate-400 font-medium">{item.desc}</p>
                  </div>
                  <button 
                    onClick={() => toggleNotif(item.key as keyof typeof notifs)}
                    className={`w-12 h-7 rounded-full transition-colors relative ${notifs[item.key as keyof typeof notifs] ? 'bg-blue-600' : 'bg-slate-200'}`}
                  >
                    <div className={`absolute top-1 left-1 bg-white w-5 h-5 rounded-full shadow-sm transition-transform ${notifs[item.key as keyof typeof notifs] ? 'translate-x-5' : ''}`}></div>
                  </button>
                </div>
              ))}
            </div>
          </div>
        );

      case 'security':
        return (
          <div className="space-y-4">
            <div className="bg-white p-5 rounded-[24px] border border-slate-50 shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="bg-blue-50 p-3 rounded-2xl text-blue-600"><Lock size={20} /></div>
                <div>
                  <p className="font-bold text-slate-800 text-sm">Change Password</p>
                  <p className="text-[10px] text-slate-400">Last updated 3 months ago</p>
                </div>
              </div>
              <ChevronRight size={18} className="text-slate-300" />
            </div>

            <div className="bg-white p-5 rounded-[24px] border border-slate-50 shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="bg-emerald-50 p-3 rounded-2xl text-emerald-600"><Smartphone size={20} /></div>
                <div>
                  <p className="font-bold text-slate-800 text-sm">Biometric Login</p>
                  <p className="text-[10px] text-slate-400">FaceID / TouchID</p>
                </div>
              </div>
              <button 
                onClick={() => toggleSecurity('biometric')}
                className={`w-10 h-6 rounded-full transition-colors relative ${security.biometric ? 'bg-emerald-500' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-1 left-1 bg-white w-4 h-4 rounded-full shadow-sm transition-transform ${security.biometric ? 'translate-x-4' : ''}`}></div>
              </button>
            </div>

            <div className="bg-white p-5 rounded-[24px] border border-slate-50 shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="bg-purple-50 p-3 rounded-2xl text-purple-600"><Key size={20} /></div>
                <div>
                  <p className="font-bold text-slate-800 text-sm">Two-Factor Auth</p>
                  <p className="text-[10px] text-slate-400">Extra layer of security</p>
                </div>
              </div>
              <button 
                onClick={() => toggleSecurity('twoFactor')}
                className={`w-10 h-6 rounded-full transition-colors relative ${security.twoFactor ? 'bg-purple-500' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-1 left-1 bg-white w-4 h-4 rounded-full shadow-sm transition-transform ${security.twoFactor ? 'translate-x-4' : ''}`}></div>
              </button>
            </div>
            
            <p className="text-center text-[10px] text-slate-400 pt-4">Your data is encrypted using AES-256 bit standard.</p>
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-4">
            <div className="bg-white rounded-[24px] border border-slate-50 overflow-hidden">
               <div className="p-5 flex justify-between items-center border-b border-slate-50">
                  <div className="flex items-center gap-3">
                    <Moon size={18} className="text-slate-400" />
                    <span className="font-bold text-slate-700 text-sm">App Theme</span>
                  </div>
                  <span className="text-[10px] font-black uppercase bg-slate-100 text-slate-500 px-2 py-1 rounded">Light</span>
               </div>
               <div className="p-5 flex justify-between items-center border-b border-slate-50">
                  <div className="flex items-center gap-3">
                    <RefreshCw size={18} className="text-slate-400" />
                    <span className="font-bold text-slate-700 text-sm">Currency</span>
                  </div>
                  <span className="text-[10px] font-black uppercase bg-slate-100 text-slate-500 px-2 py-1 rounded">INR (₹)</span>
               </div>
               <div className="p-5 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <Globe2 size={18} className="text-slate-400" />
                    <span className="font-bold text-slate-700 text-sm">Language</span>
                  </div>
                  <span className="text-[10px] font-black uppercase bg-slate-100 text-slate-500 px-2 py-1 rounded">English</span>
               </div>
            </div>

            <button className="w-full bg-red-50 text-red-500 font-bold py-4 rounded-[24px] flex items-center justify-center gap-2 active:scale-98 transition-all">
               <Trash2 size={18} /> Clear Cache & Data
            </button>
            <p className="text-[10px] text-slate-400 text-center px-4">Clearing cache will remove temporary files but won't delete your account data.</p>
          </div>
        );

      case 'support':
        return (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-indigo-500 to-blue-600 rounded-[32px] p-6 text-white shadow-lg">
              <h3 className="font-black text-lg mb-2">We're here to help!</h3>
              <p className="text-white/80 text-xs mb-6">Our support team is available Mon-Fri, 9AM - 6PM IST.</p>
              
              <div className="space-y-4">
                <div className="flex items-center gap-3 bg-white/10 p-3 rounded-2xl backdrop-blur-sm">
                  <Phone size={18} className="text-white" />
                  <span className="font-bold text-sm">+91 98765 43210</span>
                </div>
                <div className="flex items-center gap-3 bg-white/10 p-3 rounded-2xl backdrop-blur-sm">
                  <Mail size={18} className="text-white" />
                  <span className="font-bold text-sm">support@finwave.com</span>
                </div>
                <div className="flex items-center gap-3 bg-white/10 p-3 rounded-2xl backdrop-blur-sm">
                  <Globe size={18} className="text-white" />
                  <span className="font-bold text-sm">www.finwave.com</span>
                </div>
                <div className="flex items-start gap-3 bg-white/10 p-3 rounded-2xl backdrop-blur-sm">
                  <MapPin size={18} className="text-white shrink-0 mt-0.5" />
                  <span className="font-bold text-xs leading-relaxed">123, Financial District, Bandra Kurla Complex, Mumbai, India - 400051</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-2">Quick Links</p>
              {['Frequently Asked Questions', 'Terms of Service', 'Privacy Policy'].map((item) => (
                <div key={item} className="bg-white p-4 rounded-2xl border border-slate-50 flex justify-between items-center active:bg-slate-50 transition-colors cursor-pointer">
                   <span className="font-bold text-slate-700 text-sm">{item}</span>
                   <ExternalLink size={16} className="text-slate-300" />
                </div>
              ))}
            </div>
          </div>
        );

      default:
        return (
          <div className="bg-white p-10 rounded-[32px] text-center shadow-sm">
            <Settings size={40} className="mx-auto mb-4 text-blue-100 animate-spin-slow" />
            <h3 className="text-sm font-bold text-slate-700">Settings Updated</h3>
            <p className="text-[11px] text-slate-400 mt-2">Your preferences have been synced.</p>
          </div>
        );
    }
  };

  if (activeTab) {
    const item = menuItems.find(i => i.id === activeTab);
    return (
        <div className="p-6 animate-in slide-in-from-right duration-300 pb-24">
            <div className="flex items-center gap-4 mb-6">
              <button onClick={() => setActiveTab(null)} className="p-2 bg-slate-100 rounded-full hover:bg-slate-200 transition-colors">
                  <ChevronLeft size={20} className="text-slate-600" />
              </button>
              <h2 className="text-xl font-black text-slate-800 tracking-tight">{item?.label}</h2>
            </div>
            
            {renderTabContent(activeTab)}
        </div>
    );
  }

  return (
    <div className="p-6 pb-24">
      <div className="flex items-center gap-4 mb-8">
        <Link to="/" className="p-2 bg-slate-100 rounded-full text-slate-600 active:scale-90 transition-transform">
          <ChevronLeft size={20} />
        </Link>
        <h1 className="text-xl font-black text-slate-800 tracking-tight">Account Settings</h1>
      </div>

      <div className="flex flex-col items-center mb-10">
        <div className="relative mb-4 group">
          <img 
            src={MOCK_USER.avatar} 
            alt="Profile" 
            className="w-24 h-24 rounded-[32px] border-4 border-white shadow-2xl transition-transform active:scale-95 object-cover"
          />
          <div className="absolute -bottom-1 -right-1 bg-blue-600 text-white p-2 rounded-2xl border-4 border-white shadow-lg">
            <Settings size={14} className="animate-spin-slow" />
          </div>
        </div>
        <h2 className="text-2xl font-black text-slate-800 tracking-tight">{MOCK_USER.name}</h2>
        <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">{MOCK_USER.email}</p>
      </div>

      <div className="space-y-3">
        {menuItems.map((item, idx) => (
          <button 
            key={idx}
            onClick={() => {
                if(item.path) navigate(item.path);
                else setActiveTab(item.id);
            }}
            className="w-full flex items-center justify-between p-4 bg-white rounded-[24px] border border-slate-50 hover:border-blue-100 hover:bg-blue-50/20 transition-all active:scale-98 shadow-sm"
          >
            <div className="flex items-center gap-4">
              <div className={`${item.bg} p-2.5 rounded-2xl`}>
                <item.icon size={20} className={item.color} />
              </div>
              <span className="font-bold text-slate-700 text-sm">{item.label}</span>
            </div>
            <ChevronRight size={18} className="text-slate-200" />
          </button>
        ))}

        <button 
          onClick={onLogout}
          className="w-full flex items-center justify-between p-5 bg-red-50 rounded-[24px] border border-red-100 mt-8 active:scale-98 transition-all group"
        >
          <div className="flex items-center gap-4">
            <div className="bg-red-100 p-2.5 rounded-2xl group-hover:bg-red-600 group-hover:text-white transition-colors">
              <LogOut size={20} className="text-red-600 group-hover:text-white" />
            </div>
            <span className="font-black text-red-600 text-sm">Sign Out Securely</span>
          </div>
        </button>
      </div>
      
      <p className="text-center text-[10px] text-slate-300 font-bold uppercase mt-10 tracking-[0.2em]">Finwave v3.0.0</p>
    </div>
  );
};

export default Account;