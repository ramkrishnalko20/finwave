import React, { useState } from 'react';
import { 
  ChevronLeft, 
  ShieldCheck, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Fingerprint, 
  Info, 
  CreditCard,
  User,
  Loader2,
  Lock,
  Scan
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { usePortfolio } from '../PortfolioContext';

const KYC: React.FC = () => {
  const { user, updateUser } = usePortfolio();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    pan: '',
    aadhaar: '',
    fullName: user.name
  });

  const handleVerify = async () => {
    if (!formData.pan || !formData.aadhaar || !formData.fullName) return;
    
    setLoading(true);
    // Simulate API verification delay
    setTimeout(async () => {
      await updateUser({ kycStatus: 'Verified' });
      setLoading(false);
    }, 2500);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  // --- VIEW: KYC NOT COMPLETED (FORM) ---
  if (user.kycStatus !== 'Verified') {
    return (
      <div className="p-6 pb-12">
        <div className="flex items-center gap-4 mb-8">
          <Link to="/profile" className="p-2 bg-slate-100 rounded-full text-slate-600 active:scale-90 transition-transform">
            <ChevronLeft size={20} />
          </Link>
          <h1 className="text-xl font-black text-slate-800 tracking-tight">Complete KYC</h1>
        </div>

        <div className="bg-slate-900 rounded-[40px] p-8 text-white mb-8 shadow-2xl relative overflow-hidden">
          <div className="absolute -right-10 -top-10 w-40 h-40 bg-blue-500 rounded-full blur-3xl opacity-30"></div>
          <div className="relative z-10">
            <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-4 backdrop-blur-md">
              <Scan size={24} className="text-blue-300" />
            </div>
            <h2 className="text-2xl font-black mb-2">Identity Verification</h2>
            <p className="text-slate-400 text-xs font-medium leading-relaxed">
              As per SEBI regulations, linking your PAN and Aadhaar is mandatory to start investing. Your data is encrypted and secure.
            </p>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Full Legal Name</label>
            <div className="relative">
              <input 
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                placeholder="Name as per PAN"
                className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-slate-800 font-bold outline-none focus:ring-2 focus:ring-blue-500 transition-all shadow-sm"
              />
              <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            </div>
          </div>

          <div>
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">PAN Number</label>
            <div className="relative">
              <input 
                type="text"
                name="pan"
                value={formData.pan}
                onChange={(e) => setFormData(prev => ({ ...prev, pan: e.target.value.toUpperCase() }))}
                placeholder="ABCDE1234F"
                maxLength={10}
                className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-slate-800 font-black outline-none focus:ring-2 focus:ring-blue-500 transition-all shadow-sm uppercase placeholder:font-medium placeholder:text-slate-300"
              />
              <CreditCard size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              {formData.pan.length === 10 && (
                <CheckCircle2 size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-emerald-500" />
              )}
            </div>
          </div>

          <div>
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Aadhaar Number</label>
            <div className="relative">
              <input 
                type="number"
                name="aadhaar"
                value={formData.aadhaar}
                onChange={handleChange}
                placeholder="1234 5678 9012"
                maxLength={12}
                className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-slate-800 font-black outline-none focus:ring-2 focus:ring-blue-500 transition-all shadow-sm placeholder:font-medium placeholder:text-slate-300"
              />
              <Fingerprint size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              {formData.aadhaar.length >= 12 && (
                <CheckCircle2 size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-emerald-500" />
              )}
            </div>
          </div>

          <div className="pt-4">
            <button 
              onClick={handleVerify}
              disabled={loading || formData.pan.length < 10 || formData.aadhaar.length < 12}
              className="w-full bg-[#0059B2] text-white font-black py-5 rounded-[24px] shadow-xl shadow-blue-100 active:scale-95 disabled:opacity-50 disabled:active:scale-100 transition-all uppercase text-[10px] tracking-widest flex items-center justify-center gap-3"
            >
              {loading ? (
                <>
                  <Loader2 size={18} className="animate-spin" /> Verifying...
                </>
              ) : (
                <>
                  <Lock size={16} /> Verify & Link
                </>
              )}
            </button>
            <p className="text-center text-[9px] text-slate-400 mt-4 font-medium flex items-center justify-center gap-1">
              <ShieldCheck size={12} /> Powered by Central KYC Registry (CKYC)
            </p>
          </div>
        </div>
      </div>
    );
  }

  // --- VIEW: KYC COMPLETED (EXISTING VIEW) ---
  return (
    <div className="p-6">
      <div className="flex items-center gap-4 mb-8">
        <Link to="/profile" className="p-2 bg-slate-100 rounded-full text-slate-600 active:scale-90 transition-transform">
          <ChevronLeft size={20} />
        </Link>
        <h1 className="text-xl font-black text-slate-800 tracking-tight">KYC Verification</h1>
      </div>

      <div className="bg-[#0059B2] rounded-[40px] p-8 text-white mb-8 shadow-2xl relative overflow-hidden animate-in zoom-in duration-300">
        <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-10 translate-x-10 blur-3xl"></div>
        <div className="relative z-10 flex flex-col items-center text-center">
            <div className="bg-white/20 p-4 rounded-3xl mb-4 backdrop-blur-sm">
                <ShieldCheck size={40} className="text-white" />
            </div>
            <h2 className="text-2xl font-black mb-1">Status: Verified</h2>
            <p className="text-blue-100 text-xs font-bold uppercase tracking-widest opacity-80">Full Portfolio Access Enabled</p>
        </div>
      </div>

      <div className="space-y-6 animate-in slide-in-from-bottom duration-500 delay-100">
        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Verification Artifacts</h3>
        
        <div className="bg-white p-6 rounded-[32px] border border-slate-50 shadow-sm space-y-6">
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                    <div className="bg-slate-50 p-3 rounded-2xl text-slate-400">
                        <FileText size={20} />
                    </div>
                    <div>
                        <p className="text-xs font-black text-slate-800">PAN Card</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase">Linked: {user.name.slice(0,1)}****{user.name.slice(-1)}</p>
                    </div>
                </div>
                <CheckCircle2 size={20} className="text-emerald-500" />
            </div>

            <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                    <div className="bg-slate-50 p-3 rounded-2xl text-slate-400">
                        <Fingerprint size={20} />
                    </div>
                    <div>
                        <p className="text-xs font-black text-slate-800">Aadhaar Verification</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase">Biometrics Synced</p>
                    </div>
                </div>
                <CheckCircle2 size={20} className="text-emerald-500" />
            </div>

            <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                    <div className="bg-slate-50 p-3 rounded-2xl text-slate-400">
                        <AlertCircle size={20} />
                    </div>
                    <div>
                        <p className="text-xs font-black text-slate-800">In-Person Verification</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase">Digital Video Completed</p>
                    </div>
                </div>
                <CheckCircle2 size={20} className="text-emerald-500" />
            </div>
        </div>

        <div className="bg-blue-50 p-6 rounded-[32px] border border-blue-100 flex gap-4">
            <Info className="text-blue-600 shrink-0" size={20} />
            <p className="text-[10px] text-blue-700 font-bold leading-relaxed">
                Your KYC is centrally verified with KRA. You can now invest in any Mutual Fund house in India seamlessly using Finwave.
            </p>
        </div>

        {/* Debug/Demo button to reset state */}
        <button 
          onClick={() => updateUser({ kycStatus: 'Not Started' })}
          className="w-full py-4 text-slate-300 hover:text-red-400 text-[10px] font-black uppercase tracking-widest transition-colors"
        >
          [Demo: Reset Verification]
        </button>
      </div>
    </div>
  );
};

export default KYC;