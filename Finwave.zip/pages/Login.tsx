import React, { useState } from 'react';
import { ShieldCheck, Loader2, Sparkles, TrendingUp, Compass, ArrowRight } from 'lucide-react';
import { auth, signInAnonymously } from '../firebase';
import { BrandLogo } from '../components/BrandLogo';

const Login: React.FC<{ onLogin: () => void }> = ({ onLogin }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDemoLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      await signInAnonymously(auth);
      onLogin();
    } catch (err: any) {
      console.error("Demo Login Error:", err);
      setError("Demo access failed. Please refresh and try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 flex flex-col min-h-screen justify-between bg-white relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute -top-20 -left-20 w-64 h-64 bg-blue-50 rounded-full blur-3xl opacity-60"></div>
      <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-purple-50 rounded-full blur-3xl opacity-60"></div>

      <div className="relative z-10 pt-12 text-center">
        <div className="flex justify-center mb-6">
          <BrandLogo size={80} className="drop-shadow-2xl" />
        </div>
        <div className="flex flex-col gap-1 items-center">
          <h1 className="text-4xl font-black text-slate-800 tracking-tight">Finwave</h1>
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.3em] mb-2">Defining Your Wealth Identity</p>
        </div>
      </div>

      <div className="relative z-10 space-y-6">
        <div className="grid grid-cols-1 gap-4">
          <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-3xl border border-slate-100/50">
            <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-lg shadow-blue-100">
              <TrendingUp size={24} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Smart Portfolio Tracking</h3>
              <p className="text-[11px] text-slate-400 leading-tight">Real-time NAV synchronization and detailed performance analytics.</p>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-3xl border border-slate-100/50">
            <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-lg shadow-emerald-100">
              <Compass size={24} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Goal-Based Planning</h3>
              <p className="text-[11px] text-slate-400 leading-tight">Advanced calculators for retirement, SIP, and child education goals.</p>
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-4 rounded-2xl text-xs font-bold border border-red-100 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
            <ShieldCheck size={16} />
            {error}
          </div>
        )}
      </div>

      <div className="relative z-10 pb-8 space-y-4">
        <button 
          onClick={handleDemoLogin}
          disabled={loading}
          className="group w-full bg-[#0059B2] text-white font-black py-5 rounded-[28px] shadow-2xl shadow-blue-200 active:scale-95 disabled:opacity-50 transition-all uppercase text-[12px] tracking-widest flex items-center justify-center gap-3"
        >
          {loading ? (
            <Loader2 className="animate-spin" size={20} />
          ) : (
            <>
              <Sparkles size={18} />
              Start Experience
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </>
          )}
        </button>
        
        <p className="text-center text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-relaxed">
          Accessing in Secure Sandbox Mode<br/>
          No credentials required for demo
        </p>
      </div>
    </div>
  );
};

export default Login;