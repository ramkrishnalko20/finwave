import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, User, Bot, Loader2, ChevronLeft, ExternalLink, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { 
  collection, 
  addDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  deleteDoc,
  getDocs
} from 'firebase/firestore';
import { db, mockWhere, mockOrderBy, mockServerTimestamp } from '../firebase';
import { usePortfolio } from '../PortfolioContext';
import { getFinancialAdvice } from '../services/aiService';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sources?: any[];
  timestamp?: any;
}

const Assistant: React.FC = () => {
  const { folios, user, firebaseUser } = usePortfolio();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!firebaseUser) return;

    const q = query(
      collection(db, 'chats'),
      mockWhere('userId', '==', firebaseUser.uid),
      mockOrderBy('timestamp', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot: any) => {
      const msgs = snapshot.docs.map((doc: any) => ({
        id: doc.id,
        ...doc.data()
      })) as Message[];
      
      setMessages(msgs);
      setIsInitializing(false);
    });

    return () => unsubscribe();
  }, [firebaseUser]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const handleSend = async () => {
    if (!input.trim() || loading || !firebaseUser) return;

    const userQuery = input.trim();
    setInput('');
    setLoading(true);

    try {
      await addDoc(collection(db, 'chats'), {
        userId: firebaseUser.uid,
        role: 'user',
        content: userQuery,
        timestamp: mockServerTimestamp()
      });

      const portfolioContext = {
        userName: user.name,
        totalFolios: folios.length,
        holdings: folios.map(f => ({ name: f.schemeName, invested: f.investedValue }))
      };

      const result = await getFinancialAdvice(userQuery, portfolioContext);
      
      await addDoc(collection(db, 'chats'), {
        userId: firebaseUser.uid,
        role: 'assistant',
        content: result.text || "I'm sorry, I couldn't process that request.",
        sources: result.sources || [],
        timestamp: mockServerTimestamp()
      });

    } catch (err) {
      console.error("Chat Error:", err);
      await addDoc(collection(db, 'chats'), {
        userId: firebaseUser.uid,
        role: 'assistant',
        content: "I'm having trouble connecting to my brain right now. Please try again in a moment.",
        timestamp: mockServerTimestamp()
      });
    } finally {
      setLoading(false);
    }
  };

  const clearChat = async () => {
    if (!firebaseUser || !window.confirm("Clear all messages?")) return;
    try {
      const q = query(collection(db, 'chats'), mockWhere('userId', '==', firebaseUser.uid));
      const snapshot = await getDocs(q);
      const deletePromises = snapshot.docs.map((doc: any) => doc.ref.delete());
      await Promise.all(deletePromises);
    } catch (err) {
      console.error("Error clearing chat:", err);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#f8fafc]">
      <div className="p-6 bg-white border-b border-slate-100 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <Link to="/" className="p-2 bg-slate-50 rounded-full text-slate-600">
            <ChevronLeft size={20} />
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-tr from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-100">
              <Sparkles size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-black text-slate-800 tracking-tight leading-none">Finwave AI</h1>
              <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest mt-1">Online & Learning</p>
            </div>
          </div>
        </div>
        
        {messages.length > 0 && (
          <button onClick={clearChat} className="p-2 text-slate-300 hover:text-red-500 transition-colors" title="Clear Chat">
            <Trash2 size={20} />
          </button>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar">
        {isInitializing ? (
          <div className="flex flex-col items-center justify-center h-full gap-4">
            <Loader2 className="animate-spin text-blue-600" size={24} />
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Loading History...</p>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-4 max-w-xs mx-auto">
            <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
              <Sparkles size={32} />
            </div>
            <div>
              <h3 className="text-slate-800 font-bold">Start a Conversation</h3>
              <p className="text-xs text-slate-400 mt-2">Ask me about market trends, mutual funds, or your personal portfolio performance.</p>
            </div>
          </div>
        ) : (
          messages.map((m) => (
            <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`flex gap-3 max-w-[85%] ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-sm ${m.role === 'user' ? 'bg-blue-600' : 'bg-white border border-slate-100'}`}>
                  {m.role === 'user' ? <User size={16} className="text-white" /> : <Bot size={16} className="text-blue-600" />}
                </div>
                <div className={`p-4 rounded-[24px] text-sm leading-relaxed shadow-sm ${m.role === 'user' ? 'bg-blue-600 text-white rounded-tr-none' : 'bg-white text-slate-700 rounded-tl-none border border-slate-50'}`}>
                  <div className="whitespace-pre-wrap">{m.content}</div>
                  {m.sources && m.sources.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-slate-100">
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Sources & Citations</p>
                      <div className="flex flex-col gap-2">
                        {m.sources.map((chunk: any, i: number) => (
                          chunk.web && (
                            <a key={i} href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-[10px] text-blue-600 font-bold hover:underline">
                              <ExternalLink size={10} /> {chunk.web.title || 'View Source'}
                            </a>
                          )
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
        {loading && (
          <div className="flex justify-start">
            <div className="flex gap-3 max-w-[85%]">
              <div className="w-8 h-8 rounded-xl bg-white border border-slate-100 flex items-center justify-center shrink-0 animate-pulse">
                <Bot size={16} className="text-blue-600" />
              </div>
              <div className="p-4 bg-white border border-slate-50 rounded-[24px] rounded-tl-none shadow-sm">
                <Loader2 size={16} className="animate-spin text-blue-400" />
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-white border-t border-slate-100 shrink-0 pb-28">
        <div className="relative flex items-center">
          <input 
            type="text"
            placeholder="Ask about your portfolio or funds..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            className="w-full bg-slate-100 border-none rounded-[24px] py-4 pl-6 pr-14 text-slate-800 font-medium text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
          <button onClick={handleSend} disabled={!input.trim() || loading} className="absolute right-2 p-3 bg-blue-600 text-white rounded-full shadow-lg shadow-blue-200 active:scale-90 disabled:opacity-50 transition-all">
            <Send size={18} />
          </button>
        </div>
        <p className="text-[9px] text-slate-400 text-center mt-3 font-bold uppercase tracking-widest">Finwave AI can make mistakes. Check important info.</p>
      </div>
    </div>
  );
};

export default Assistant;
