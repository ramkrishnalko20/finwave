
import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight, 
  ChevronRight, 
  Filter, 
  Download, 
  PieChart as PieIcon,
  TrendingUp as TrendIcon,
  Loader2,
  Trash2,
  X,
  Plus,
  Minus,
  ChevronLeft,
  CheckCircle2
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid 
} from 'recharts';
import { MOCK_PORTFOLIO } from '../constants';
import { Folio } from '../types';
import { Link, useNavigate } from 'react-router-dom';
import { usePortfolio } from '../PortfolioContext';

const Assets: React.FC = () => {
  const { folios, removeFolio, quickTransaction, formatCurrency } = usePortfolio();
  const [liveFolios, setLiveFolios] = useState<Folio[]>([]);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const [totalValue, setTotalValue] = useState(0);
  const [totalReturns, setTotalReturns] = useState(0);
  const [activeTab, setActiveTab] = useState<'holdings' | 'allocation'>('holdings');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRealTimeData = async () => {
      if (folios.length === 0) {
        setLiveFolios([]);
        setTotalValue(0);
        setTotalReturns(0);
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        const updated = await Promise.all(
          folios.map(async (f) => {
            try {
              const res = await fetch(`https://api.mfapi.in/mf/${f.schemeCode}`);
              const data = await res.json();
              
              if (data && data.data && data.data.length > 0) {
                const latestNav = parseFloat(data.data[0].nav);
                const currentValue = f.units * latestNav;
                const returns = currentValue - f.investedValue;
                const returnsPercent = (returns / f.investedValue) * 100;

                return {
                  ...f,
                  currentNav: latestNav,
                  currentValue,
                  returns,
                  returnsPercent
                };
              }
            } catch (err) {
              console.warn(`Sync failed for ${f.schemeCode}:`, err);
            }
            return { ...f, currentNav: 0, currentValue: f.investedValue, returns: 0, returnsPercent: 0 };
          })
        );

        setLiveFolios(updated);
        const totalVal = updated.reduce((sum, f) => sum + (f.currentValue || 0), 0);
        const totalInvested = updated.reduce((sum, f) => sum + f.investedValue, 0);
        setTotalValue(totalVal);
        setTotalReturns(totalVal - totalInvested);
      } catch (err) {
        console.error("Failed to sync live data", err);
      } finally {
        setLoading(false);
      }
    };

    fetchRealTimeData();
  }, [folios]);

  const handleDownloadReport = () => {
    setDownloading(true);
    
    // Create CSV content
    const headers = ["Scheme Name", "Folio Number", "Plan Type", "Investment Type", "Units", "Invested Value", "Current Value", "Returns (INR)", "Returns (%)"];
    const rows = liveFolios.map(f => [
      `"${f.schemeName}"`,
      f.folioNumber,
      f.planType,
      f.investmentType,
      f.units.toFixed(4),
      f.investedValue.toFixed(2),
      (f.currentValue || 0).toFixed(2),
      (f.returns || 0).toFixed(2),
      (f.returnsPercent || 0).toFixed(2)
    ]);

    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Finwave_Portfolio_Report_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    
    setTimeout(() => {
      link.click();
      document.body.removeChild(link);
      setDownloading(false);
    }, 1200); 
  };

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  const handleQuickTx = (folioId: string, type: 'BUY' | 'SELL', nav: number) => {
    if (!nav || nav <= 0) return;
    quickTransaction(folioId, type, nav);
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      const amount = totalValue > 0 ? (totalValue * data.value) / 100 : 0;
      
      return (
        <div className="bg-slate-900 text-white p-4 rounded-[24px] shadow-2xl border border-white/10 animate-in zoom-in duration-200">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-2.5 h-2.5 rounded-full shadow-[0_0_8px_rgba(255,255,255,0.3)]" style={{ backgroundColor: data.fill || data.color }}></div>
            <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">{data.name}</p>
          </div>
          
          <div className="space-y-1">
            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Market Value</p>
            <p className="text-xl font-black text-white tracking-tighter">
              {formatCurrency(amount)}
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-white/5 flex justify-between items-center gap-6">
             <div className="flex flex-col">
                <span className="text-[8px] font-black text-slate-500 uppercase">Portfolio Share</span>
                <span className="text-xs font-black text-blue-400">{data.value}%</span>
             </div>
             <div className="bg-blue-600/20 px-2 py-1 rounded-lg">
                <TrendingUp size={12} className="text-blue-400" />
             </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-6 pb-12">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center gap-3">
          <Link to="/" className="p-2 bg-slate-100 rounded-full text-slate-600 active:scale-90 transition-transform">
            <ChevronLeft size={20} />
          </Link>
          <h1 className="text-2xl font-black text-slate-800 tracking-tight">Full Portfolio</h1>
        </div>
        <div className="flex gap-2">
            <button 
              onClick={handleDownloadReport}
              disabled={downloading || liveFolios.length === 0}
              className={`p-2 rounded-xl active:scale-95 transition-all flex items-center justify-center ${downloading ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500 disabled:opacity-50'}`}
            >
              {downloading ? <Loader2 size={20} className="animate-spin" /> : <Download size={20} />}
            </button>
            <button className="p-2 bg-slate-100 rounded-xl text-slate-500 active:scale-95 transition-all"><Filter size={20} /></button>
        </div>
      </div>

      <div className="bg-slate-900 rounded-[32px] p-8 text-white mb-8 shadow-2xl relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-500/20 rounded-full blur-3xl"></div>
        <div className="relative z-10">
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">Combined Asset Value</p>
            {loading ? <div className="h-10 w-40 bg-slate-800 animate-pulse rounded-lg" /> : (
                <h2 className="text-3xl font-black mb-4">{formatCurrency(totalValue)}</h2>
            )}
            
            <div className="flex gap-6 items-center">
                <div className="space-y-0.5">
                    <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest">Returns</p>
                    <div className={`flex items-center gap-1 ${totalReturns >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        {totalReturns >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                        <span className="text-sm font-bold">{formatCurrency(totalReturns)}</span>
                    </div>
                </div>
                <div className="w-px h-8 bg-slate-800"></div>
                <div className="space-y-0.5">
                    <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest">Growth</p>
                    <div className={`flex items-center gap-1 ${totalReturns >= 0 ? 'text-blue-400' : 'text-red-400'}`}>
                        <TrendIcon size={14} />
                        <span className="text-sm font-bold">
                            {totalValue > 0 ? ((totalReturns / (totalValue - totalReturns)) * 100).toFixed(2) : '0'}%
                        </span>
                    </div>
                </div>
            </div>
        </div>
      </div>

      <div className="flex bg-slate-100 p-1.5 rounded-2xl mb-8">
        <button 
            onClick={() => setActiveTab('holdings')}
            className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 ${activeTab === 'holdings' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
        >
            <TrendIcon size={16} /> My Holdings
        </button>
        <button 
            onClick={() => setActiveTab('allocation')}
            className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 ${activeTab === 'allocation' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
        >
            <PieIcon size={16} /> Allocation
        </button>
      </div>

      {activeTab === 'holdings' ? (
        <div className="space-y-4">
            <div className="flex justify-between items-center mb-2 px-1">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{liveFolios.length} Active Folios</p>
                <Link to="/explore" className="text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center gap-1">
                  <Plus size={12} /> Add Scheme
                </Link>
            </div>
            {loading ? (
                [1, 2, 3].map(i => <div key={i} className="h-28 bg-white rounded-3xl animate-pulse border border-slate-50" />)
            ) : liveFolios.length === 0 ? (
                <div className="text-center py-20 bg-white rounded-[32px] border border-dashed border-slate-200">
                    <p className="text-slate-400 font-bold mb-4">No investments found.</p>
                    <Link to="/explore" className="bg-blue-600 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest">Explore Funds</Link>
                </div>
            ) : (
                liveFolios.map((folio: any) => (
                    <div 
                        key={folio.id} 
                        className="bg-white p-6 rounded-[32px] border border-slate-50 shadow-sm hover:shadow-lg hover:border-blue-100 transition-all group overflow-hidden"
                    >
                        <div className="flex justify-between items-start mb-4">
                            <div className="flex-1 pr-4" onClick={() => navigate(`/folio/${folio.id}`)}>
                                <h4 className="font-bold text-slate-800 text-sm leading-tight mb-1 group-hover:text-blue-600 transition-colors">{folio.schemeName}</h4>
                                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">Units: {folio.units.toFixed(2)} • {folio.investmentType}</p>
                            </div>
                            <button 
                                onClick={() => removeFolio(folio.id)}
                                className="p-2 text-slate-200 hover:text-red-500 transition-colors"
                            >
                                <Trash2 size={18} />
                            </button>
                        </div>

                        <div className="flex justify-between items-end border-t border-slate-50 pt-4 mb-6">
                            <div className="flex items-end gap-6">
                                <div>
                                    <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest mb-0.5">Current Value</p>
                                    <p className="text-lg font-black text-slate-800">{formatCurrency(folio.currentValue)}</p>
                                </div>
                                <div className="pb-0.5">
                                    <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest mb-0.5">NAV</p>
                                    <p className="text-[11px] font-bold text-slate-500">{formatCurrency(folio.currentNav)}</p>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest mb-0.5">Total Return</p>
                                <div className={`flex items-center justify-end gap-1 font-black text-xs ${(folio.returns || 0) >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                                    {(folio.returns || 0) >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                                    {folio.returnsPercent?.toFixed(2)}%
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <button 
                                onClick={() => handleQuickTx(folio.id, 'BUY', folio.currentNav)}
                                className="bg-blue-600 text-white py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-100 active:scale-95 transition-all flex items-center justify-center gap-2"
                            >
                                <Plus size={14} /> Quick Buy
                            </button>
                            <button 
                                onClick={() => handleQuickTx(folio.id, 'SELL', folio.currentNav)}
                                className="bg-slate-50 text-slate-600 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest border border-slate-100 active:scale-95 transition-all flex items-center justify-center gap-2"
                            >
                                <Minus size={14} /> Quick Sell
                            </button>
                        </div>
                    </div>
                ))
            )}
        </div>
      ) : (
        <div className="animate-in fade-in duration-500">
            <div className="bg-white rounded-[40px] p-8 shadow-sm border border-slate-50 mb-8">
                <h4 className="text-sm font-bold text-slate-800 mb-8 flex items-center gap-2">
                    <div className="w-1.5 h-4 bg-blue-600 rounded-full"></div> Asset Allocation
                </h4>
                <div className="h-64 relative">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={MOCK_PORTFOLIO.assetAllocation}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={85}
                                paddingAngle={8}
                                dataKey="value"
                                stroke="none"
                            >
                                {MOCK_PORTFOLIO.assetAllocation.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip content={<CustomTooltip />} />
                        </PieChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Equity</span>
                        <span className="text-xl font-black text-slate-800">85%</span>
                    </div>
                </div>

                <div className="mt-8 grid grid-cols-2 gap-4">
                    {MOCK_PORTFOLIO.assetAllocation.map((asset, idx) => (
                        <div key={asset.name} className="flex items-center gap-3 p-3 bg-slate-50 rounded-2xl">
                            <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }}></div>
                            <div>
                                <p className="text-[10px] font-black text-slate-400 uppercase leading-none mb-1">{asset.name}</p>
                                <p className="text-xs font-bold text-slate-800">
                                  {formatCurrency((totalValue * asset.value) / 100)}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="bg-blue-50 border border-blue-100 rounded-[32px] p-8">
                <h4 className="text-blue-900 font-bold text-sm mb-4">Portfolio Analysis</h4>
                <p className="text-blue-800/60 text-xs leading-relaxed font-medium">
                    Your portfolio is currently aggressive with an 85% tilt towards Equity. This is suitable for long-term wealth creation but may see higher volatility in the short term.
                </p>
                <div className="mt-6 flex gap-4">
                    <div className="flex-1 bg-white p-4 rounded-2xl shadow-sm border border-blue-200/50">
                        <p className="text-[9px] font-black text-blue-400 uppercase mb-1">Risk Profile</p>
                        <p className="text-sm font-black text-blue-700">Aggressive</p>
                    </div>
                    <div className="flex-1 bg-white p-4 rounded-2xl shadow-sm border border-blue-200/50">
                        <p className="text-[9px] font-black text-blue-400 uppercase mb-1">Time Horizon</p>
                        <p className="text-sm font-black text-blue-700">7+ Years</p>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default Assets;
