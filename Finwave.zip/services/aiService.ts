import { GoogleGenAI } from "@google/genai";

// Initialize lazily to prevent runtime crashes if env vars are missing in production
let ai: GoogleGenAI | null = null;

export const getFinancialAdvice = async (prompt: string, portfolioContext: any) => {
  try {
    // Safe access to process.env for production builds with fallback check
    const apiKey = (typeof process !== 'undefined' && process.env) ? process.env.API_KEY : undefined;

    // Check if key is missing or is explicitly undefined/placeholder
    if (!apiKey || apiKey === 'undefined' || !apiKey.startsWith('AI')) {
      return {
        text: "### 🚀 Demo Mode Active\n\n**Note for Site Owner:** The AI Assistant is currently running in demonstration mode because a valid Gemini API Key was not detected.\n\nTo enable live AI responses on Hostinger:\n1. Get an API Key from Google AI Studio.\n2. Add `API_KEY` to your build environment variables.\n\n*Simulated Response:* Based on your current portfolio structure, diversifying into Debt funds might reduce overall volatility while maintaining steady growth.",
        sources: []
      };
    }

    if (!ai) {
      ai = new GoogleGenAI({ apiKey });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          text: `You are Finwave AI, a professional financial advisor. 
          User Portfolio Context: ${JSON.stringify(portfolioContext)}
          
          Guidelines:
          1. Be concise and professional.
          2. Use formatting (bolding, lists) for clarity.
          3. If recommending funds, use Google Search to get current performance.
          4. Always warn that market investments are subject to risk.
          
          User Query: ${prompt}`
        }
      ],
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.7,
        topP: 0.8,
        topK: 40
      }
    });

    const text = response.text;
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    return {
      text,
      sources
    };
  } catch (error) {
    console.error("AI Service Error:", error);
    // Return a graceful error message instead of throwing, to keep the UI intact
    return {
        text: "I'm having trouble connecting to the financial services right now. Please check your network connection or try again later.",
        sources: []
    };
  }
};