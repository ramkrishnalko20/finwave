
import React from 'react';

export const BrandLogo: React.FC<{ size?: number; className?: string }> = ({ size = 40, className = "" }) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background shape mimicking the 'd' curve */}
      <path 
        d="M20 50C20 33.4315 33.4315 20 50 20C66.5685 20 80 33.4315 80 50C80 66.5685 66.5685 80 50 80H20V50Z" 
        fill="#0059B2" 
      />
      {/* Wave shape and 'Fin' accent */}
      <path 
        d="M20 80L45 55L60 70L80 50" 
        stroke="white" 
        strokeWidth="8" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
      />
      {/* Purple 'Rock' accent */}
      <path 
        d="M60 50H95V85H60V50Z" 
        fill="#6300A5" 
      />
      {/* Pixel/Digital accents from designRock logo */}
      <rect x="85" y="40" width="10" height="10" fill="#6300A5" opacity="0.6" />
      <rect x="75" y="30" width="6" height="6" fill="#0059B2" />
      {/* Yellow 'Identity' spark */}
      <circle cx="25" cy="55" r="8" fill="#FFD700" />
      <path d="M10 45L25 55L10 65" fill="#FF8C00" />
    </svg>
  );
};
